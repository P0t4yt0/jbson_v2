-- MySQL dump 10.13  Distrib 8.4.9, for Win64 (x86_64)
--
-- Host: localhost    Database: jbson_dev
-- ------------------------------------------------------
-- Server version	8.4.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditlog_logentry`
--

DROP TABLE IF EXISTS `auditlog_logentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditlog_logentry` (
  `id` int NOT NULL AUTO_INCREMENT,
  `object_pk` varchar(255) NOT NULL,
  `object_id` bigint DEFAULT NULL,
  `object_repr` longtext NOT NULL,
  `action` smallint unsigned NOT NULL,
  `changes` json DEFAULT NULL,
  `timestamp` datetime(6) NOT NULL,
  `actor_id` bigint DEFAULT NULL,
  `content_type_id` int NOT NULL,
  `remote_addr` char(39) DEFAULT NULL,
  `additional_data` json DEFAULT NULL,
  `serialized_data` json DEFAULT NULL,
  `cid` varchar(255) DEFAULT NULL,
  `changes_text` longtext NOT NULL,
  `remote_port` int unsigned DEFAULT NULL,
  `actor_email` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `auditlog_logentry_actor_id_959271d2_fk_security_user_id` (`actor_id`),
  KEY `auditlog_logentry_content_type_id_75830218_fk_django_co` (`content_type_id`),
  KEY `auditlog_logentry_object_id_09c2eee8` (`object_id`),
  KEY `auditlog_logentry_object_pk_6e3219c0` (`object_pk`),
  KEY `auditlog_logentry_action_229afe39` (`action`),
  KEY `auditlog_logentry_timestamp_37867bb0` (`timestamp`),
  KEY `auditlog_logentry_cid_9f467263` (`cid`),
  CONSTRAINT `auditlog_logentry_actor_id_959271d2_fk_security_user_id` FOREIGN KEY (`actor_id`) REFERENCES `security_user` (`id`),
  CONSTRAINT `auditlog_logentry_content_type_id_75830218_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `auditlog_logentry_chk_2` CHECK ((`action` >= 0)),
  CONSTRAINT `auditlog_logentry_chk_3` CHECK ((`remote_port` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditlog_logentry`
--

LOCK TABLES `auditlog_logentry` WRITE;
/*!40000 ALTER TABLE `auditlog_logentry` DISABLE KEYS */;
INSERT INTO `auditlog_logentry` VALUES (1,'9',9,'InventoryItem object (9)',2,'{\"id\": [\"9\", \"None\"], \"price\": [\"110.00\", \"None\"], \"category\": [\"10\", \"None\"], \"quantity\": [\"120\", \"None\"], \"supplier\": [\"8\", \"None\"], \"item_name\": [\" Atlanta PVC Pipe 1/2\\\" Blue\", \"None\"], \"unit_cost\": [\"85.00\", \"None\"], \"barcode_id\": [\"4807000800090\", \"None\"], \"date_added\": [\"2026-05-07 14:03:59.588681\", \"None\"], \"product_id\": [\"PL001\", \"None\"], \"sold_items\": [\"point_of_sale.TransactionItem.None\", \"None\"], \"description\": [\"\", \"None\"], \"date_updated\": [\"2026-05-08 04:03:12.347794\", \"None\"], \"annual_demand\": [\"1000\", \"None\"], \"reorder_point\": [\"10\", \"None\"], \"registration_logs\": [\"product_registration.ProductRegistrationLog.None\", \"None\"], \"abc_classification\": [\"C\", \"None\"], \"actual_sales_count\": [\"0\", \"None\"], \"manual_annual_demand\": [\"0\", \"None\"]}','2026-05-08 06:12:24.402971',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(2,'6',6,'InventoryItem object (6)',2,'{\"id\": [\"6\", \"None\"], \"price\": [\"160.00\", \"None\"], \"category\": [\"1\", \"None\"], \"quantity\": [\"60\", \"None\"], \"supplier\": [\"5\", \"None\"], \"item_name\": [\" Boysen Latex Colors 1/4L\", \"None\"], \"unit_cost\": [\"120.00\", \"None\"], \"barcode_id\": [\"4804000500060\", \"None\"], \"date_added\": [\"2026-05-07 14:01:43.237746\", \"None\"], \"product_id\": [\"PN001\", \"None\"], \"sold_items\": [\"point_of_sale.TransactionItem.None\", \"None\"], \"description\": [\"\", \"None\"], \"date_updated\": [\"2026-05-08 04:03:12.324496\", \"None\"], \"annual_demand\": [\"2000\", \"None\"], \"reorder_point\": [\"10\", \"None\"], \"registration_logs\": [\"product_registration.ProductRegistrationLog.None\", \"None\"], \"abc_classification\": [\"B\", \"None\"], \"actual_sales_count\": [\"0\", \"None\"], \"manual_annual_demand\": [\"0\", \"None\"]}','2026-05-08 06:34:09.898854',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(3,'11',11,'InventoryItem object (11)',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"8\", \"90\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol\", \" Green Cross Alcohol \"], \"unit_cost\": [\"100.00\", \"0.00\"], \"annual_demand\": [\"2000\", \"0\"]}','2026-05-08 06:42:22.583905',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(4,'11',11,'InventoryItem object (11)',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"90\", \"67\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol \", \" Green Cross Alcohol  \"], \"unit_cost\": [\"0.00\", \"100\"], \"annual_demand\": [\"0\", \"2500\"]}','2026-05-08 06:48:00.506733',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(5,'7',7,'InventoryItem object (7)',1,'{\"category\": [\"8\", \"8\"], \"quantity\": [\"5\", \"88\"], \"supplier\": [\"6\", \"6\"], \"item_name\": [\" Stanley Tape Measure 5m\", \" Stanley Tape Measure 5m \"], \"unit_cost\": [\"180.00\", \"180\"]}','2026-05-08 06:49:37.357306',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(6,'5',5,'InventoryItem object (5)',1,'{\"abc_classification\": [\"B\", \"A\"]}','2026-05-08 06:49:38.770443',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(7,'11',11,'InventoryItem object (11)',1,'{\"abc_classification\": [\"B\", \"A\"]}','2026-05-08 06:49:38.783455',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(8,'7',7,'InventoryItem object (7)',1,'{\"abc_classification\": [\"C\", \"B\"]}','2026-05-08 06:49:38.792973',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(9,'11',11,'InventoryItem object (11)',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"67\", \"99\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol  \", \" Green Cross Alcohol   \"], \"unit_cost\": [\"100.00\", \"\"], \"annual_demand\": [\"2500\", \"0\"]}','2026-05-08 06:51:37.433208',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(10,'11',11,'InventoryItem object (11)',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"67\", \"99\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol  \", \" Green Cross Alcohol   \"], \"unit_cost\": [\"100.00\", \"\"], \"annual_demand\": [\"2500\", \"0\"]}','2026-05-08 06:54:41.201366',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(11,'11',11,'InventoryItem object (11)',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"67\", \"99\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol  \", \" Green Cross Alcohol   \"], \"unit_cost\": [\"100.00\", \"\"], \"annual_demand\": [\"2500\", \"0\"]}','2026-05-08 06:54:44.345027',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(12,'11',11,'InventoryItem object (11)',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"67\", \"99\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol  \", \" Green Cross Alcohol   \"], \"unit_cost\": [\"100.00\", \"0\"], \"annual_demand\": [\"2500\", \"0\"]}','2026-05-08 06:54:50.181895',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(13,'8',8,'InventoryItem object (8)',1,'{\"abc_classification\": [\"C\", \"B\"]}','2026-05-08 06:55:46.764278',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(14,'11',11,'InventoryItem object (11)',1,'{\"abc_classification\": [\"A\", \"C\"]}','2026-05-08 06:55:46.780460',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(15,'10',10,'InventoryItem object (10)',1,'{\"category\": [\"11\", \"11\"], \"quantity\": [\"8\", \"88\"], \"supplier\": [\"9\", \"9\"], \"item_name\": [\" Omni LED Bulb 9W Daylight\", \" Omni LED Bulb 9W Daylight \"], \"unit_cost\": [\"75.00\", \"0.00\"], \"annual_demand\": [\"800\", \"0\"]}','2026-05-08 07:01:30.413251',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(16,'8',8,'InventoryItem object (8)',1,'{\"abc_classification\": [\"B\", \"C\"]}','2026-05-08 07:01:31.692311',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(17,'11',11,'InventoryItem object (11)',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"99\", \"6\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol   \", \" Green Cross Alcohol    \"]}','2026-05-08 07:02:51.941968',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(18,'5',5,'InventoryItem object (5)',1,'{\"category\": [\"7\", \"7\"], \"quantity\": [\"45\", \"8\"], \"supplier\": [\"4\", \"4\"], \"item_name\": [\" WD-40 Multi-Use 412g\", \" WD-40 Multi-Use 412g \"], \"unit_cost\": [\"250.00\", \"0.00\"], \"annual_demand\": [\"1200\", \"0\"]}','2026-05-08 07:03:10.741851',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(19,'7',7,'InventoryItem object (7)',1,'{\"abc_classification\": [\"B\", \"A\"]}','2026-05-08 07:03:11.644818',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(20,'5',5,'InventoryItem object (5)',1,'{\"abc_classification\": [\"A\", \"C\"]}','2026-05-08 07:03:11.683554',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(21,'8',8,'InventoryItem object (8)',1,'{\"category\": [\"9\", \"9\"], \"supplier\": [\"7\", \"7\"], \"item_name\": [\" Common Wire Nails 2\\\" (1kg)\", \" Common Wire Nails 2\\\" (1kg) \"], \"unit_cost\": [\"60.00\", \"60\"]}','2026-05-08 08:18:56.511514',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(22,'8',8,'InventoryItem object (8)',1,'{\"category\": [\"9\", \"9\"], \"supplier\": [\"7\", \"7\"], \"item_name\": [\" Common Wire Nails 2\\\" (1kg) \", \" Common Wire Nails 2\\\" (1kg)  \"]}','2026-05-08 08:22:35.786012',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(23,'11',11,'InventoryItem object (11)',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"6\", \"7\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol    \", \" Green Cross Alcohol     \"]}','2026-05-08 08:26:01.963612',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(24,'7',7,'InventoryItem object (7)',1,'{\"category\": [\"8\", \"8\"], \"quantity\": [\"88\", \"9999\"], \"supplier\": [\"6\", \"6\"], \"item_name\": [\" Stanley Tape Measure 5m \", \" Stanley Tape Measure 5m  \"]}','2026-05-08 08:26:54.444189',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(25,'11',11,'InventoryItem object (11)',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"7\", \"88\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol     \", \" Green Cross Alcohol      \"]}','2026-05-08 08:27:00.655003',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(26,'10',10,'InventoryItem object (10)',1,'{\"category\": [\"11\", \"11\"], \"supplier\": [\"9\", \"9\"], \"item_name\": [\" Omni LED Bulb 9W Daylight \", \" Omni LED Bulb 9W Daylight  \"], \"unit_cost\": [\"0.00\", \"75\"], \"annual_demand\": [\"0\", \"800\"]}','2026-05-08 08:27:26.122687',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(27,'8',8,'InventoryItem object (8)',1,'{\"abc_classification\": [\"C\", \"B\"]}','2026-05-08 08:27:27.295200',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(28,'11',11,' Green Cross Alcohol',1,'{\"category\": [\"5\", \"5\"], \"quantity\": [\"88\", \"99\"], \"supplier\": [\"1\", \"1\"], \"item_name\": [\" Green Cross Alcohol      \", \" Green Cross Alcohol\"]}','2026-05-08 08:32:08.657557',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(29,'5',5,' WD-40 Multi-Use 412g  ',1,'{\"category\": [\"7\", \"7\"], \"supplier\": [\"4\", \"4\"], \"item_name\": [\" WD-40 Multi-Use 412g \", \" WD-40 Multi-Use 412g  \"], \"unit_cost\": [\"0.00\", \"250\"], \"annual_demand\": [\"0\", \"1200\"]}','2026-05-08 08:32:37.403630',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(30,'5',5,' WD-40 Multi-Use 412g  ',1,'{\"abc_classification\": [\"C\", \"A\"]}','2026-05-08 08:32:38.878941',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(31,'7',7,' Stanley Tape Measure 5m  ',1,'{\"abc_classification\": [\"A\", \"B\"]}','2026-05-08 08:32:38.891423',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(32,'10',10,'Gardenia Bakeries',0,'{\"id\": [\"None\", \"10\"], \"name\": [\"None\", \"Gardenia Bakeries\"], \"email\": [\"None\", \"\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"phone\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"created_at\": [\"None\", \"2026-05-08 08:34:55.794444\"], \"supplier_id\": [\"None\", \"SUP-PXCF\"], \"contact_name\": [\"None\", \"\"]}','2026-05-08 08:34:55.803077',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(33,'12',12,' Gardenia Classic White Bread',0,'{\"id\": [\"None\", \"12\"], \"price\": [\"None\", \"82.00\"], \"category\": [\"None\", \"8\"], \"quantity\": [\"None\", \"15\"], \"supplier\": [\"None\", \"10\"], \"item_name\": [\"None\", \" Gardenia Classic White Bread\"], \"unit_cost\": [\"None\", \"68.00\"], \"barcode_id\": [\"None\", \"4805555666677\"], \"date_added\": [\"None\", \"2026-05-08 08:35:19.551518\"], \"product_id\": [\"None\", \"HAT002\"], \"sold_items\": [\"None\", \"point_of_sale.TransactionItem.None\"], \"description\": [\"None\", \"\"], \"date_updated\": [\"None\", \"2026-05-08 08:35:19.554024\"], \"annual_demand\": [\"None\", \"2500\"], \"reorder_point\": [\"None\", \"10\"], \"registration_logs\": [\"None\", \"product_registration.ProductRegistrationLog.None\"], \"abc_classification\": [\"None\", \"U\"], \"actual_sales_count\": [\"None\", \"0\"], \"manual_annual_demand\": [\"None\", \"0\"]}','2026-05-08 08:35:19.559205',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(34,'12',12,' Gardenia Classic White Bread',1,'{\"abc_classification\": [\"U\", \"A\"]}','2026-05-08 08:35:22.315556',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(35,'8',8,' Common Wire Nails 2\" (1kg)  ',1,'{\"abc_classification\": [\"B\", \"C\"]}','2026-05-08 08:35:22.332806',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(36,'12',12,' Gardenia Classic White Bread',2,'{\"id\": [\"12\", \"None\"], \"price\": [\"82.00\", \"None\"], \"category\": [\"8\", \"None\"], \"quantity\": [\"15\", \"None\"], \"supplier\": [\"10\", \"None\"], \"item_name\": [\" Gardenia Classic White Bread\", \"None\"], \"unit_cost\": [\"68.00\", \"None\"], \"barcode_id\": [\"4805555666677\", \"None\"], \"date_added\": [\"2026-05-08 08:35:19.551518\", \"None\"], \"product_id\": [\"HAT002\", \"None\"], \"sold_items\": [\"point_of_sale.TransactionItem.None\", \"None\"], \"description\": [\"\", \"None\"], \"date_updated\": [\"2026-05-08 08:35:22.320472\", \"None\"], \"annual_demand\": [\"2500\", \"None\"], \"reorder_point\": [\"10\", \"None\"], \"registration_logs\": [\"product_registration.ProductRegistrationLog.None\", \"None\"], \"abc_classification\": [\"A\", \"None\"], \"actual_sales_count\": [\"0\", \"None\"], \"manual_annual_demand\": [\"0\", \"None\"]}','2026-05-08 08:35:44.926440',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(42,'8',8,' Common Wire Nails 2\" (1kg)  ',1,'{\"abc_classification\": [\"C\", \"B\"]}','2026-05-08 09:35:15.883875',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(43,'12',12,'Alcohol',2,'{\"id\": [\"12\", \"None\"], \"name\": [\"Alcohol\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"AL\", \"None\"], \"created_at\": [\"2026-05-08 04:02:32.456438\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-08 11:44:11.262152',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(44,'13',13,'Bakery',2,'{\"id\": [\"13\", \"None\"], \"name\": [\"Bakery\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"BKR\", \"None\"], \"created_at\": [\"2026-05-08 08:34:19.693970\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-08 11:44:14.441387',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(45,'4',4,'PAINT',2,'{\"id\": [\"4\", \"None\"], \"name\": [\"PAINT\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"PT\", \"None\"], \"created_at\": [\"2026-05-07 13:38:33.343017\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-08 11:44:18.338719',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(46,'19',19,'test',2,'{\"id\": [\"19\", \"None\"], \"name\": [\"test\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"TST\", \"None\"], \"created_at\": [\"2026-05-08 09:35:40.277022\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-08 11:44:22.911675',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(47,'8',8,' Common Wire Nails 2\" (1kg)   (HW)',1,'{\"quantity\": [\"150\", \"146\"]}','2026-05-08 12:13:03.235806',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(48,'7',7,' Stanley Tape Measure 5m   (HAT)',1,'{\"quantity\": [\"9999\", \"9997\"]}','2026-05-08 12:13:03.280249',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(49,'5',5,' WD-40 Multi-Use 412g    ( MT)',1,'{\"category\": [\"7\", \"7\"], \"quantity\": [\"8\", \"5\"], \"supplier\": [\"4\", \"4\"], \"item_name\": [\" WD-40 Multi-Use 412g  \", \" WD-40 Multi-Use 412g   \"]}','2026-05-08 13:51:37.267917',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(50,'6',6,'test3 (Employee)',2,'{\"id\": [\"6\", \"None\"], \"role\": [\"Employee\", \"None\"], \"backups\": [\"maintenance.BackupRecord.None\", \"None\"], \"reports\": [\"reports_analytics.Report.None\", \"None\"], \"is_staff\": [\"False\", \"None\"], \"payments\": [\"billing_payment.Payment.None\", \"None\"], \"restores\": [\"maintenance.RestoreRecord.None\", \"None\"], \"searches\": [\"search.SearchLog.None\", \"None\"], \"username\": [\"test3\", \"None\"], \"full_name\": [\"test3\", \"None\"], \"is_active\": [\"True\", \"None\"], \"date_created\": [\"2026-05-08 09:02:55.921272\", \"None\"], \"is_superuser\": [\"False\", \"None\"], \"transactions\": [\"point_of_sale.Transaction.None\", \"None\"], \"activity_logs\": [\"activity_log.ActivityLog.None\", \"None\"], \"notifications\": [\"notifications.Notification.None\", \"None\"], \"security_logs\": [\"security.ActivityLog.None\", \"None\"], \"manual_articles\": [\"user_manual.ManualArticle.None\", \"None\"], \"manual_sections\": [\"user_manual.ManualSection.None\", \"None\"]}','2026-05-08 14:09:53.488270',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(51,'3',3,'wejelle (Admin)',2,'{\"id\": [\"3\", \"None\"], \"role\": [\"Admin\", \"None\"], \"backups\": [\"maintenance.BackupRecord.None\", \"None\"], \"reports\": [\"reports_analytics.Report.None\", \"None\"], \"is_staff\": [\"True\", \"None\"], \"payments\": [\"billing_payment.Payment.None\", \"None\"], \"restores\": [\"maintenance.RestoreRecord.None\", \"None\"], \"searches\": [\"search.SearchLog.None\", \"None\"], \"username\": [\"wejelle\", \"None\"], \"full_name\": [\"wejelle lucero\", \"None\"], \"is_active\": [\"True\", \"None\"], \"date_created\": [\"2026-05-08 08:41:15.985822\", \"None\"], \"is_superuser\": [\"True\", \"None\"], \"transactions\": [\"point_of_sale.Transaction.None\", \"None\"], \"activity_logs\": [\"activity_log.ActivityLog.None\", \"None\"], \"notifications\": [\"notifications.Notification.None\", \"None\"], \"security_logs\": [\"security.ActivityLog.None\", \"None\"], \"manual_articles\": [\"user_manual.ManualArticle.None\", \"None\"], \"manual_sections\": [\"user_manual.ManualSection.None\", \"None\"]}','2026-05-08 14:09:58.385379',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(52,'4',4,'testing (Employee)',2,'{\"id\": [\"4\", \"None\"], \"role\": [\"Employee\", \"None\"], \"backups\": [\"maintenance.BackupRecord.None\", \"None\"], \"reports\": [\"reports_analytics.Report.None\", \"None\"], \"is_staff\": [\"False\", \"None\"], \"payments\": [\"billing_payment.Payment.None\", \"None\"], \"restores\": [\"maintenance.RestoreRecord.None\", \"None\"], \"searches\": [\"search.SearchLog.None\", \"None\"], \"username\": [\"testing\", \"None\"], \"full_name\": [\"test\", \"None\"], \"is_active\": [\"True\", \"None\"], \"date_created\": [\"2026-05-08 08:48:45.187951\", \"None\"], \"is_superuser\": [\"False\", \"None\"], \"transactions\": [\"point_of_sale.Transaction.None\", \"None\"], \"activity_logs\": [\"activity_log.ActivityLog.None\", \"None\"], \"notifications\": [\"notifications.Notification.None\", \"None\"], \"security_logs\": [\"security.ActivityLog.None\", \"None\"], \"manual_articles\": [\"user_manual.ManualArticle.None\", \"None\"], \"manual_sections\": [\"user_manual.ManualSection.None\", \"None\"]}','2026-05-08 14:10:01.619216',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(53,'5',5,'test2 (Employee)',2,'{\"id\": [\"5\", \"None\"], \"role\": [\"Employee\", \"None\"], \"backups\": [\"maintenance.BackupRecord.None\", \"None\"], \"reports\": [\"reports_analytics.Report.None\", \"None\"], \"is_staff\": [\"False\", \"None\"], \"payments\": [\"billing_payment.Payment.None\", \"None\"], \"restores\": [\"maintenance.RestoreRecord.None\", \"None\"], \"searches\": [\"search.SearchLog.None\", \"None\"], \"username\": [\"test2\", \"None\"], \"full_name\": [\"test2\", \"None\"], \"is_active\": [\"True\", \"None\"], \"date_created\": [\"2026-05-08 08:50:15.550436\", \"None\"], \"is_superuser\": [\"False\", \"None\"], \"transactions\": [\"point_of_sale.Transaction.None\", \"None\"], \"activity_logs\": [\"activity_log.ActivityLog.None\", \"None\"], \"notifications\": [\"notifications.Notification.None\", \"None\"], \"security_logs\": [\"security.ActivityLog.None\", \"None\"], \"manual_articles\": [\"user_manual.ManualArticle.None\", \"None\"], \"manual_sections\": [\"user_manual.ManualSection.None\", \"None\"]}','2026-05-08 14:10:04.243511',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(55,'7',7,' Stanley Tape Measure 5m   (HAT)',1,'{\"quantity\": [\"9997\", \"9992\"]}','2026-05-08 14:44:06.898943',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(56,'5',5,' WD-40 Multi-Use 412g     ( MT)',1,'{\"category\": [\"7\", \"7\"], \"quantity\": [\"5\", \"99\"], \"supplier\": [\"4\", \"4\"], \"item_name\": [\" WD-40 Multi-Use 412g   \", \" WD-40 Multi-Use 412g    \"]}','2026-05-09 02:39:52.998572',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(57,'1',1,'Paints',2,'{\"id\": [\"1\", \"None\"], \"name\": [\"Paints\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"PN\", \"None\"], \"created_at\": [\"2026-05-07 13:37:38.411049\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-09 03:19:01.089409',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(58,'10',10,'Plumbing',2,'{\"id\": [\"10\", \"None\"], \"name\": [\"Plumbing\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"PL\", \"None\"], \"created_at\": [\"2026-05-07 14:03:33.181860\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-09 03:19:04.749728',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(59,'6',6,'Power Tools',2,'{\"id\": [\"6\", \"None\"], \"name\": [\"Power Tools\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"POT\", \"None\"], \"created_at\": [\"2026-05-07 13:59:45.947811\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-09 03:19:07.334128',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(60,'7',7,' Stanley Tape Measure 5m   (HAT)',1,'{\"quantity\": [\"9992\", \"9925\"]}','2026-05-09 03:19:45.448229',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(61,'7',7,'test (Employee)',0,'{\"id\": [\"None\", \"7\"], \"role\": [\"None\", \"Employee\"], \"backups\": [\"None\", \"maintenance.BackupRecord.None\"], \"reports\": [\"None\", \"reports_analytics.Report.None\"], \"is_staff\": [\"None\", \"False\"], \"payments\": [\"None\", \"billing_payment.Payment.None\"], \"restores\": [\"None\", \"maintenance.RestoreRecord.None\"], \"searches\": [\"None\", \"search.SearchLog.None\"], \"username\": [\"None\", \"test\"], \"full_name\": [\"None\", \"test\"], \"is_active\": [\"None\", \"True\"], \"date_created\": [\"None\", \"2026-05-09 03:20:16.748397\"], \"is_superuser\": [\"None\", \"False\"], \"transactions\": [\"None\", \"point_of_sale.Transaction.None\"], \"activity_logs\": [\"None\", \"activity_log.ActivityLog.None\"], \"notifications\": [\"None\", \"notifications.Notification.None\"], \"security_logs\": [\"None\", \"security.ActivityLog.None\"], \"manual_articles\": [\"None\", \"user_manual.ManualArticle.None\"], \"manual_sections\": [\"None\", \"user_manual.ManualSection.None\"]}','2026-05-09 03:20:17.146030',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(62,'7',7,'test (Employee)',2,'{\"id\": [\"7\", \"None\"], \"role\": [\"Employee\", \"None\"], \"backups\": [\"maintenance.BackupRecord.None\", \"None\"], \"reports\": [\"reports_analytics.Report.None\", \"None\"], \"is_staff\": [\"False\", \"None\"], \"payments\": [\"billing_payment.Payment.None\", \"None\"], \"restores\": [\"maintenance.RestoreRecord.None\", \"None\"], \"searches\": [\"search.SearchLog.None\", \"None\"], \"username\": [\"test\", \"None\"], \"full_name\": [\"test\", \"None\"], \"is_active\": [\"True\", \"None\"], \"date_created\": [\"2026-05-09 03:20:16.748397\", \"None\"], \"is_superuser\": [\"False\", \"None\"], \"transactions\": [\"point_of_sale.Transaction.None\", \"None\"], \"activity_logs\": [\"activity_log.ActivityLog.None\", \"None\"], \"notifications\": [\"notifications.Notification.None\", \"None\"], \"security_logs\": [\"security.ActivityLog.None\", \"None\"], \"manual_articles\": [\"user_manual.ManualArticle.None\", \"None\"], \"manual_sections\": [\"user_manual.ManualSection.None\", \"None\"]}','2026-05-09 03:20:20.958356',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(63,'7',7,' Stanley Tape Measure 5m   (HAT)',1,'{\"quantity\": [\"9925\", \"9921\"]}','2026-05-09 03:56:36.724630',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(64,'7',7,' Stanley Tape Measure 5m   (HAT)',1,'{\"quantity\": [\"9921\", \"9909\"]}','2026-05-09 07:50:00.876956',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(65,'10',10,' Omni LED Bulb 9W Daylight   (EL)',1,'{\"quantity\": [\"88\", \"78\"]}','2026-05-09 07:50:00.889630',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(66,'8',8,' Common Wire Nails 2\" (1kg)   (HW)',1,'{\"quantity\": [\"146\", \"137\"]}','2026-05-09 07:50:00.898763',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(67,'5',5,' WD-40 Multi-Use 412g     ( MT)',1,'{\"quantity\": [\"99\", \"86\"]}','2026-05-09 07:50:00.908918',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(68,'11',11,' Green Cross Alcohol (CO)',1,'{\"quantity\": [\"99\", \"88\"]}','2026-05-09 07:50:00.920812',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(69,'11',11,'Pioneer Adhesives Inc.',0,'{\"id\": [\"None\", \"11\"], \"name\": [\"None\", \"Pioneer Adhesives Inc.\"], \"email\": [\"None\", \"\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"phone\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"created_at\": [\"None\", \"2026-05-09 08:01:50.090993\"], \"supplier_id\": [\"None\", \"SUP-40XW\"], \"contact_name\": [\"None\", \"\"]}','2026-05-09 08:01:50.103003',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(70,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',0,'{\"id\": [\"None\", \"13\"], \"price\": [\"None\", \"180.00\"], \"category\": [\"None\", \"7\"], \"quantity\": [\"None\", \"42\"], \"supplier\": [\"None\", \"11\"], \"item_name\": [\"None\", \" Pioneer Epoxy Clay Aqua\"], \"unit_cost\": [\"None\", \"135.00\"], \"barcode_id\": [\"None\", \"4801111222333\"], \"date_added\": [\"None\", \"2026-05-09 08:01:54.146354\"], \"product_id\": [\"None\", \" MT002\"], \"sold_items\": [\"None\", \"point_of_sale.TransactionItem.None\"], \"description\": [\"None\", \"\"], \"date_updated\": [\"None\", \"2026-05-09 08:01:54.150465\"], \"annual_demand\": [\"None\", \"120\"], \"reorder_point\": [\"None\", \"10\"], \"registration_logs\": [\"None\", \"product_registration.ProductRegistrationLog.None\"], \"abc_classification\": [\"None\", \"U\"], \"actual_sales_count\": [\"None\", \"0\"], \"manual_annual_demand\": [\"None\", \"0\"]}','2026-05-09 08:01:54.158311',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(71,'12',12,'Pacific Paint (Boysen) Phils.',0,'{\"id\": [\"None\", \"12\"], \"name\": [\"None\", \"Pacific Paint (Boysen) Phils.\"], \"email\": [\"None\", \"\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"phone\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"created_at\": [\"None\", \"2026-05-09 08:02:11.853719\"], \"supplier_id\": [\"None\", \"SUP-D2LN\"], \"contact_name\": [\"None\", \"\"]}','2026-05-09 08:02:11.861368',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(72,'14',14,' Boysen Paint Thinner 1L ( MT)',0,'{\"id\": [\"None\", \"14\"], \"price\": [\"None\", \"125.00\"], \"category\": [\"None\", \"7\"], \"quantity\": [\"None\", \"65\"], \"supplier\": [\"None\", \"5\"], \"item_name\": [\"None\", \" Boysen Paint Thinner 1L\"], \"unit_cost\": [\"None\", \"90.00\"], \"barcode_id\": [\"None\", \"4802222333444\"], \"date_added\": [\"None\", \"2026-05-09 08:02:39.113009\"], \"product_id\": [\"None\", \" MT003\"], \"sold_items\": [\"None\", \"point_of_sale.TransactionItem.None\"], \"description\": [\"None\", \"\"], \"date_updated\": [\"None\", \"2026-05-09 08:02:39.116349\"], \"annual_demand\": [\"None\", \"300\"], \"reorder_point\": [\"None\", \"10\"], \"registration_logs\": [\"None\", \"product_registration.ProductRegistrationLog.None\"], \"abc_classification\": [\"None\", \"U\"], \"actual_sales_count\": [\"None\", \"0\"], \"manual_annual_demand\": [\"None\", \"0\"]}','2026-05-09 08:02:39.121337',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(73,'13',13,'3M Philippines',0,'{\"id\": [\"None\", \"13\"], \"name\": [\"None\", \"3M Philippines\"], \"email\": [\"None\", \"\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"phone\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"created_at\": [\"None\", \"2026-05-09 08:02:59.526237\"], \"supplier_id\": [\"None\", \"SUP-KJDQ\"], \"contact_name\": [\"None\", \"\"]}','2026-05-09 08:02:59.533768',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(74,'15',15,' 3M Scotch-Brite Heavy Duty ( MT)',0,'{\"id\": [\"None\", \"15\"], \"price\": [\"None\", \"45.00\"], \"category\": [\"None\", \"7\"], \"quantity\": [\"None\", \"150\"], \"supplier\": [\"None\", \"13\"], \"item_name\": [\"None\", \" 3M Scotch-Brite Heavy Duty\"], \"unit_cost\": [\"None\", \"28.00\"], \"barcode_id\": [\"None\", \"4803333444555\"], \"date_added\": [\"None\", \"2026-05-09 08:03:20.177835\"], \"product_id\": [\"None\", \" MT004\"], \"sold_items\": [\"None\", \"point_of_sale.TransactionItem.None\"], \"description\": [\"None\", \"\"], \"date_updated\": [\"None\", \"2026-05-09 08:03:20.181442\"], \"annual_demand\": [\"None\", \"850\"], \"reorder_point\": [\"None\", \"10\"], \"registration_logs\": [\"None\", \"product_registration.ProductRegistrationLog.None\"], \"abc_classification\": [\"None\", \"U\"], \"actual_sales_count\": [\"None\", \"0\"], \"manual_annual_demand\": [\"None\", \"0\"]}','2026-05-09 08:03:20.186507',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(75,'14',14,'Cord Chemicals Inc.',0,'{\"id\": [\"None\", \"14\"], \"name\": [\"None\", \"Cord Chemicals Inc.\"], \"email\": [\"None\", \"\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"phone\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"created_at\": [\"None\", \"2026-05-09 08:03:53.954774\"], \"supplier_id\": [\"None\", \"SUP-R35I\"], \"contact_name\": [\"None\", \"\"]}','2026-05-09 08:03:53.961863',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(76,'16',16,' Mighty Bond Instant Glue 3g ( MT)',0,'{\"id\": [\"None\", \"16\"], \"price\": [\"None\", \"65.00\"], \"category\": [\"None\", \"7\"], \"quantity\": [\"None\", \"88\"], \"supplier\": [\"None\", \"14\"], \"item_name\": [\"None\", \" Mighty Bond Instant Glue 3g\"], \"unit_cost\": [\"None\", \"48.00\"], \"barcode_id\": [\"None\", \"4804444555666\"], \"date_added\": [\"None\", \"2026-05-09 08:04:18.106042\"], \"product_id\": [\"None\", \" MT005\"], \"sold_items\": [\"None\", \"point_of_sale.TransactionItem.None\"], \"description\": [\"None\", \"\"], \"date_updated\": [\"None\", \"2026-05-09 08:04:18.108548\"], \"annual_demand\": [\"None\", \"450\"], \"reorder_point\": [\"None\", \"10\"], \"registration_logs\": [\"None\", \"product_registration.ProductRegistrationLog.None\"], \"abc_classification\": [\"None\", \"U\"], \"actual_sales_count\": [\"None\", \"0\"], \"manual_annual_demand\": [\"None\", \"0\"]}','2026-05-09 08:04:18.113845',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(77,'15',15,'Bostik Philippines',0,'{\"id\": [\"None\", \"15\"], \"name\": [\"None\", \"Bostik Philippines\"], \"email\": [\"None\", \"\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"phone\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"created_at\": [\"None\", \"2026-05-09 08:04:37.587176\"], \"supplier_id\": [\"None\", \"SUP-G92N\"], \"contact_name\": [\"None\", \"\"]}','2026-05-09 08:04:37.591389',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(78,'17',17,' Bostik No More Nails 320g ( MT)',0,'{\"id\": [\"None\", \"17\"], \"price\": [\"None\", \"295.00\"], \"category\": [\"None\", \"7\"], \"quantity\": [\"None\", \"24\"], \"supplier\": [\"None\", \"15\"], \"item_name\": [\"None\", \" Bostik No More Nails 320g\"], \"unit_cost\": [\"None\", \"210.00\"], \"barcode_id\": [\"None\", \"4805555666777\"], \"date_added\": [\"None\", \"2026-05-09 08:05:18.154907\"], \"product_id\": [\"None\", \" MT006\"], \"sold_items\": [\"None\", \"point_of_sale.TransactionItem.None\"], \"description\": [\"None\", \"\"], \"date_updated\": [\"None\", \"2026-05-09 08:05:18.159211\"], \"annual_demand\": [\"None\", \"85\"], \"reorder_point\": [\"None\", \"10\"], \"registration_logs\": [\"None\", \"product_registration.ProductRegistrationLog.None\"], \"abc_classification\": [\"None\", \"U\"], \"actual_sales_count\": [\"None\", \"0\"], \"manual_annual_demand\": [\"None\", \"0\"]}','2026-05-09 08:05:18.164529',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(79,'7',7,' Stanley Tape Measure 5m   (HAT)',1,'{\"abc_classification\": [\"B\", \"A\"]}','2026-05-09 08:05:48.485874',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(80,'10',10,' Omni LED Bulb 9W Daylight   (EL)',1,'{\"abc_classification\": [\"C\", \"B\"]}','2026-05-09 08:05:48.505780',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(81,'14',14,' Boysen Paint Thinner 1L ( MT)',1,'{\"abc_classification\": [\"U\", \"B\"]}','2026-05-09 08:05:48.517325',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(82,'15',15,' 3M Scotch-Brite Heavy Duty ( MT)',1,'{\"abc_classification\": [\"U\", \"C\"]}','2026-05-09 08:05:48.530468',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(83,'16',16,' Mighty Bond Instant Glue 3g ( MT)',1,'{\"abc_classification\": [\"U\", \"C\"]}','2026-05-09 08:05:48.541615',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(84,'17',17,' Bostik No More Nails 320g ( MT)',1,'{\"abc_classification\": [\"U\", \"C\"]}','2026-05-09 08:05:48.554808',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(85,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"abc_classification\": [\"U\", \"C\"]}','2026-05-09 08:05:48.565764',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(86,'16',16,'QC Industrial Fasteners',0,'{\"id\": [\"None\", \"16\"], \"name\": [\"None\", \"QC Industrial Fasteners\"], \"email\": [\"None\", \"\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"phone\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"created_at\": [\"None\", \"2026-05-09 08:07:12.481596\"], \"supplier_id\": [\"None\", \"SUP-267A\"], \"contact_name\": [\"None\", \"\"]}','2026-05-09 08:07:12.490858',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(87,'18',18,' Tox with Screws Set 6mm (100s) ( MT)',0,'{\"id\": [\"None\", \"18\"], \"price\": [\"None\", \"55.00\"], \"category\": [\"None\", \"7\"], \"quantity\": [\"None\", \"210\"], \"supplier\": [\"None\", \"16\"], \"item_name\": [\"None\", \" Tox with Screws Set 6mm (100s)\"], \"unit_cost\": [\"None\", \"35.00\"], \"barcode_id\": [\"None\", \"4806666777888\"], \"date_added\": [\"None\", \"2026-05-09 08:07:38.071610\"], \"product_id\": [\"None\", \" MT007\"], \"sold_items\": [\"None\", \"point_of_sale.TransactionItem.None\"], \"description\": [\"None\", \"\"], \"date_updated\": [\"None\", \"2026-05-09 08:07:38.075443\"], \"annual_demand\": [\"None\", \"1200\"], \"reorder_point\": [\"None\", \"10\"], \"registration_logs\": [\"None\", \"product_registration.ProductRegistrationLog.None\"], \"abc_classification\": [\"None\", \"U\"], \"actual_sales_count\": [\"None\", \"0\"], \"manual_annual_demand\": [\"None\", \"0\"]}','2026-05-09 08:07:38.080747',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(88,'18',18,' Tox with Screws Set 6mm (100s) ( MT)',1,'{\"abc_classification\": [\"U\", \"B\"]}','2026-05-09 08:07:45.378981',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(89,'18',18,' Tox with Screws Set 6mm (100s)  (HW)',1,'{\"category\": [\"7\", \"9\"], \"supplier\": [\"16\", \"16\"], \"item_name\": [\" Tox with Screws Set 6mm (100s)\", \" Tox with Screws Set 6mm (100s) \"]}','2026-05-09 08:08:11.207799',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(90,'17',17,' Bostik No More Nails 320g ( MT)',1,'{\"quantity\": [\"24\", \"21\"]}','2026-05-10 08:30:14.716411',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(91,'8',8,' Common Wire Nails 2\" (1kg)   (HW)',1,'{\"quantity\": [\"137\", \"133\"]}','2026-05-10 08:30:14.731296',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(92,'14',14,' Boysen Paint Thinner 1L ( MT)',1,'{\"quantity\": [\"65\", \"64\"]}','2026-05-10 08:30:14.741853',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(93,'16',16,' Mighty Bond Instant Glue 3g ( MT)',1,'{\"quantity\": [\"88\", \"86\"]}','2026-05-10 08:30:14.753178',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(94,'11',11,' Green Cross Alcohol (CO)',1,'{\"quantity\": [\"88\", \"87\"]}','2026-05-10 08:30:14.763682',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(95,'8',8,' Common Wire Nails 2\" (1kg)   (HW)',1,'{\"quantity\": [\"133\", \"128\"]}','2026-05-10 10:46:24.486632',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(96,'17',17,' Bostik No More Nails 320g ( MT)',1,'{\"quantity\": [\"21\", \"20\"]}','2026-05-10 10:46:24.499554',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(97,'15',15,' 3M Scotch-Brite Heavy Duty ( MT)',1,'{\"quantity\": [\"150\", \"149\"]}','2026-05-10 10:46:24.512388',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(98,'14',14,' Boysen Paint Thinner 1L ( MT)',1,'{\"quantity\": [\"64\", \"62\"]}','2026-05-10 10:46:24.524455',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(99,'16',16,' Mighty Bond Instant Glue 3g ( MT)',1,'{\"quantity\": [\"86\", \"84\"]}','2026-05-10 10:46:24.536366',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(100,'11',11,' Green Cross Alcohol (CO)',1,'{\"quantity\": [\"87\", \"86\"]}','2026-05-10 10:46:24.548635',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(101,'2',2,'jewelle (Employee)',2,'{\"id\": [\"2\", \"None\"], \"role\": [\"Employee\", \"None\"], \"backups\": [\"maintenance.BackupRecord.None\", \"None\"], \"reports\": [\"reports_analytics.Report.None\", \"None\"], \"is_staff\": [\"False\", \"None\"], \"payments\": [\"billing_payment.Payment.None\", \"None\"], \"restores\": [\"maintenance.RestoreRecord.None\", \"None\"], \"searches\": [\"search.SearchLog.None\", \"None\"], \"username\": [\"jewelle\", \"None\"], \"full_name\": [\"jewelle lucero\", \"None\"], \"is_active\": [\"True\", \"None\"], \"date_created\": [\"2026-05-03 14:34:27.731007\", \"None\"], \"is_superuser\": [\"False\", \"None\"], \"transactions\": [\"point_of_sale.Transaction.None\", \"None\"], \"activity_logs\": [\"activity_log.ActivityLog.None\", \"None\"], \"notifications\": [\"notifications.Notification.None\", \"None\"], \"security_logs\": [\"security.ActivityLog.None\", \"None\"], \"manual_articles\": [\"user_manual.ManualArticle.None\", \"None\"], \"manual_sections\": [\"user_manual.ManualSection.None\", \"None\"]}','2026-05-10 12:15:19.340819',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(102,'8',8,'jewelle (Employee)',0,'{\"id\": [\"None\", \"8\"], \"role\": [\"None\", \"Employee\"], \"backups\": [\"None\", \"maintenance.BackupRecord.None\"], \"reports\": [\"None\", \"reports_analytics.Report.None\"], \"is_staff\": [\"None\", \"False\"], \"payments\": [\"None\", \"billing_payment.Payment.None\"], \"restores\": [\"None\", \"maintenance.RestoreRecord.None\"], \"searches\": [\"None\", \"search.SearchLog.None\"], \"username\": [\"None\", \"jewelle\"], \"full_name\": [\"None\", \"jewelle lucero\"], \"is_active\": [\"None\", \"True\"], \"date_created\": [\"None\", \"2026-05-10 12:15:38.609707\"], \"is_superuser\": [\"None\", \"False\"], \"transactions\": [\"None\", \"point_of_sale.Transaction.None\"], \"activity_logs\": [\"None\", \"activity_log.ActivityLog.None\"], \"notifications\": [\"None\", \"notifications.Notification.None\"], \"security_logs\": [\"None\", \"security.ActivityLog.None\"], \"manual_articles\": [\"None\", \"user_manual.ManualArticle.None\"], \"manual_sections\": [\"None\", \"user_manual.ManualSection.None\"]}','2026-05-10 12:15:39.051843',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(103,'10',10,'Gardenia Bakeries',1,'{\"is_active\": [\"True\", \"False\"]}','2026-05-11 07:36:28.343894',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(104,'10',10,'Gardenia Bakeries',1,'{\"is_active\": [\"False\", \"True\"]}','2026-05-11 07:36:41.758495',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(105,'17',17,'jewelle',0,'{\"id\": [\"None\", \"17\"], \"name\": [\"None\", \"jewelle\"], \"email\": [\"None\", \"qjrblucero01@tip.edu.ph\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"phone\": [\"None\", \"\"], \"address\": [\"None\", \"Balayan\"], \"is_active\": [\"None\", \"True\"], \"created_at\": [\"None\", \"2026-05-11 07:37:06.951698\"], \"contact_name\": [\"None\", \"JEWELLE RUBY LUCERO\"], \"purchase_orders\": [\"None\", \"inventory.PurchaseOrder.None\"]}','2026-05-11 07:37:06.957855',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(106,'17',17,'jewelle',1,'{\"is_active\": [\"True\", \"False\"]}','2026-05-11 07:37:13.659940',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(107,'14',14,' Boysen Paint Thinner 1L ( MT)',1,'{\"quantity\": [\"62\", \"61\"]}','2026-05-11 08:49:05.815045',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(108,'8',8,' Common Wire Nails 2\" (1kg)   (HW)',1,'{\"quantity\": [\"128\", \"127\"]}','2026-05-11 08:49:05.827865',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(109,'17',17,' Bostik No More Nails 320g ( MT)',1,'{\"quantity\": [\"20\", \"19\"]}','2026-05-11 08:49:05.844295',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(118,'8',8,' Common Wire Nails 2\" (1kg)   (HW)',1,'{\"quantity\": [\"127\", \"126\"]}','2026-05-11 09:32:52.505055',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(119,'14',14,' Boysen Paint Thinner 1L ( MT)',1,'{\"quantity\": [\"61\", \"58\"]}','2026-05-11 09:32:52.519390',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(120,'17',17,' Bostik No More Nails 320g ( MT)',1,'{\"quantity\": [\"19\", \"16\"]}','2026-05-11 09:32:52.530965',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(121,'16',16,' Mighty Bond Instant Glue 3g ( MT)',1,'{\"quantity\": [\"84\", \"81\"]}','2026-05-11 09:32:52.543724',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(122,'10',10,' Omni LED Bulb 9W Daylight   (EL)',1,'{\"quantity\": [\"78\", \"76\"]}','2026-05-11 09:32:52.557154',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(123,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"42\", \"41\"]}','2026-05-11 09:32:52.568082',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(124,'18',18,' Tox with Screws Set 6mm (100s)  (HW)',1,'{\"quantity\": [\"210\", \"209\"]}','2026-05-11 09:32:52.581122',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(125,'5',5,' WD-40 Multi-Use 412g     ( MT)',1,'{\"quantity\": [\"86\", \"85\"]}','2026-05-11 09:32:52.593363',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(126,'11',11,' Green Cross Alcohol (CO)',1,'{\"quantity\": [\"86\", \"85\"]}','2026-05-11 09:32:52.604463',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(127,'1',1,'PO-C97D2C - ABC',0,'{\"id\": [\"None\", \"1\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"1\"], \"po_number\": [\"None\", \"PO-C97D2C\"], \"order_date\": [\"None\", \"2026-05-11 09:33:15.729192\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-28\"]}','2026-05-11 09:33:15.737411',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(128,'1',1,'PO-C97D2C - ABC',1,'{\"total_amount\": [\"0.00\", \"1960.00\"]}','2026-05-11 09:33:15.749478',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(129,'18',18,' Tox with Screws Set 6mm (100s)  (HW)',1,'{\"quantity\": [\"209\", \"265\"]}','2026-05-11 09:33:42.000513',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(130,'1',1,'PO-C97D2C - ABC',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-11 09:33:42.020560',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(131,'14',14,' Boysen Paint Thinner 1L ( MT)',1,'{\"quantity\": [\"58\", \"57\"]}','2026-05-11 10:04:22.178494',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(132,'17',17,' Bostik No More Nails 320g ( MT)',1,'{\"quantity\": [\"16\", \"15\"]}','2026-05-11 10:04:22.193805',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(133,'16',16,' Mighty Bond Instant Glue 3g ( MT)',1,'{\"quantity\": [\"81\", \"80\"]}','2026-05-11 10:04:22.203632',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(134,'10',10,' Omni LED Bulb 9W Daylight   (EL)',1,'{\"quantity\": [\"76\", \"74\"]}','2026-05-11 10:04:22.216017',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(135,'8',8,' Common Wire Nails 2\" (1kg)   (HW)',1,'{\"quantity\": [\"126\", \"124\"]}','2026-05-11 10:04:22.227436',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(136,'13',13,'3M Philippines',1,'{\"is_active\": [\"True\", \"False\"]}','2026-05-11 10:06:46.557618',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(137,'2',2,'PO-BC6513 - ABC',0,'{\"id\": [\"None\", \"2\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"1\"], \"po_number\": [\"None\", \"PO-BC6513\"], \"order_date\": [\"None\", \"2026-05-12 02:34:24.810936\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-12\"]}','2026-05-12 02:34:24.819560',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(138,'2',2,'PO-BC6513 - ABC',1,'{\"total_amount\": [\"0.00\", \"4489.00\"]}','2026-05-12 02:34:24.833751',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(139,'11',11,' Green Cross Alcohol (CO)',1,'{\"quantity\": [\"85\", \"152\"], \"unit_cost\": [\"0.00\", \"67.00\"]}','2026-05-12 02:34:48.119916',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(140,'2',2,'PO-BC6513 - ABC',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-12 02:34:48.141459',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(141,'17',17,' Bostik No More Nails 320g  ( MT)',1,'{\"category\": [\"7\", \"7\"], \"quantity\": [\"15\", \"7\"], \"supplier\": [\"15\", \"15\"], \"item_name\": [\" Bostik No More Nails 320g\", \" Bostik No More Nails 320g \"]}','2026-05-12 02:36:22.931350',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(142,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"41\", \"4\"]}','2026-05-12 02:37:44.027234',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(143,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"4\", \"3\"]}','2026-05-12 02:38:42.859794',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(144,'15',15,' 3M Scotch-Brite Heavy Duty ( MT)',1,'{\"quantity\": [\"149\", \"147\"]}','2026-05-12 05:18:17.225301',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(145,'3',3,'PO-EE51C0 - Pioneer Adhesives Inc.',0,'{\"id\": [\"None\", \"3\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"11\"], \"po_number\": [\"None\", \"PO-EE51C0\"], \"order_date\": [\"None\", \"2026-05-12 06:54:53.888476\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-19\"]}','2026-05-12 06:54:53.897052',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(146,'3',3,'PO-EE51C0 - Pioneer Adhesives Inc.',1,'{\"total_amount\": [\"0.00\", \"2295.00\"]}','2026-05-12 06:54:53.909879',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(147,'4',4,'PO-88514E - Bostik Philippines',0,'{\"id\": [\"None\", \"4\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"15\"], \"po_number\": [\"None\", \"PO-88514E\"], \"order_date\": [\"None\", \"2026-05-12 06:56:17.641942\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-19\"]}','2026-05-12 06:56:17.650378',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(148,'4',4,'PO-88514E - Bostik Philippines',1,'{\"total_amount\": [\"0.00\", \"2730.00\"]}','2026-05-12 06:56:17.663964',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(149,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"3\", \"20\"]}','2026-05-13 08:35:24.878991',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(150,'3',3,'PO-EE51C0 - Pioneer Adhesives Inc.',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-13 08:35:24.904174',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(151,'17',17,' Bostik No More Nails 320g  ( MT)',1,'{\"quantity\": [\"7\", \"20\"]}','2026-05-13 08:35:38.160017',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(152,'4',4,'PO-88514E - Bostik Philippines',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-13 08:35:38.180054',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(153,'20',20,'TEST',0,'{\"id\": [\"None\", \"20\"], \"name\": [\"None\", \"TEST\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"prefix\": [\"None\", \"TE\"], \"created_at\": [\"None\", \"2026-05-13 09:29:39.931502\"], \"description\": [\"None\", \"\"]}','2026-05-13 09:29:39.942899',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(154,'20',20,'TEST',2,'{\"id\": [\"20\", \"None\"], \"name\": [\"TEST\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"TE\", \"None\"], \"created_at\": [\"2026-05-13 09:29:39.931502\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-13 09:29:45.503107',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(155,'21',21,'Jewelle Lucero',0,'{\"id\": [\"None\", \"21\"], \"name\": [\"None\", \"Jewelle Lucero\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"prefix\": [\"None\", \"JL\"], \"created_at\": [\"None\", \"2026-05-13 09:29:55.413977\"], \"description\": [\"None\", \"\"]}','2026-05-13 09:29:55.419414',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(156,'21',21,'Jewelle Lucero',2,'{\"id\": [\"21\", \"None\"], \"name\": [\"Jewelle Lucero\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"JL\", \"None\"], \"created_at\": [\"2026-05-13 09:29:55.413977\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-13 09:30:00.259377',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(157,'22',22,'TEST',0,'{\"id\": [\"None\", \"22\"], \"name\": [\"None\", \"TEST\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"prefix\": [\"None\", \"TE\"], \"created_at\": [\"None\", \"2026-05-13 09:32:09.804750\"], \"description\": [\"None\", \"\"]}','2026-05-13 09:32:09.811798',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(158,'23',23,'jewelle',0,'{\"id\": [\"None\", \"23\"], \"name\": [\"None\", \"jewelle\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"prefix\": [\"None\", \"JE\"], \"created_at\": [\"None\", \"2026-05-13 09:36:51.212833\"], \"description\": [\"None\", \"\"]}','2026-05-13 09:36:51.218900',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(159,'23',23,'jewelle',2,'{\"id\": [\"23\", \"None\"], \"name\": [\"jewelle\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"JE\", \"None\"], \"created_at\": [\"2026-05-13 09:36:51.212833\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-13 09:36:56.869466',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(160,'24',24,'jewelle',0,'{\"id\": [\"None\", \"24\"], \"name\": [\"None\", \"jewelle\"], \"items\": [\"None\", \"inventory.InventoryItem.None\"], \"prefix\": [\"None\", \"JWL\"], \"created_at\": [\"None\", \"2026-05-13 09:40:10.234127\"], \"description\": [\"None\", \"\"]}','2026-05-13 09:40:10.238653',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(161,'24',24,'jewelle',2,'{\"id\": [\"24\", \"None\"], \"name\": [\"jewelle\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"JWL\", \"None\"], \"created_at\": [\"2026-05-13 09:40:10.234127\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-13 09:40:14.102708',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(162,'22',22,'TEST',2,'{\"id\": [\"22\", \"None\"], \"name\": [\"TEST\", \"None\"], \"items\": [\"inventory.InventoryItem.None\", \"None\"], \"prefix\": [\"TE\", \"None\"], \"created_at\": [\"2026-05-13 09:32:09.804750\", \"None\"], \"description\": [\"\", \"None\"]}','2026-05-13 09:57:38.185619',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(163,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"20\", \"2\"]}','2026-05-15 03:18:16.182576',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(164,'5',5,'PO-09D5DE - Pioneer Adhesives Inc.',0,'{\"id\": [\"None\", \"5\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"11\"], \"po_number\": [\"None\", \"PO-09D5DE\"], \"order_date\": [\"None\", \"2026-05-15 03:19:09.674676\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-22\"]}','2026-05-15 03:19:09.737933',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(165,'5',5,'PO-09D5DE - Pioneer Adhesives Inc.',1,'{\"total_amount\": [\"0.00\", \"13500.00\"]}','2026-05-15 03:19:09.758247',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(166,'6',6,'PO-CCD6F2 - Yatai Int\'l',0,'{\"id\": [\"None\", \"6\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"9\"], \"po_number\": [\"None\", \"PO-CCD6F2\"], \"order_date\": [\"None\", \"2026-05-15 03:19:33.606749\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-15\"]}','2026-05-15 03:19:33.670972',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(167,'6',6,'PO-CCD6F2 - Yatai Int\'l',1,'{\"total_amount\": [\"0.00\", \"150.00\"]}','2026-05-15 03:19:33.686201',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(168,'21',21,' Alcohol (HAT)',0,'{\"id\": [\"None\", \"21\"], \"price\": [\"None\", \"100\"], \"category\": [\"None\", \"8\"], \"quantity\": [\"None\", \"50\"], \"supplier\": [\"None\", \"1\"], \"item_name\": [\"None\", \" Alcohol\"], \"unit_cost\": [\"None\", \"90\"], \"barcode_id\": [\"None\", \"4806520413889\"], \"date_added\": [\"None\", \"2026-05-15 03:25:49.566070\"], \"product_id\": [\"None\", \"HAT002\"], \"sold_items\": [\"None\", \"point_of_sale.TransactionItem.None\"], \"description\": [\"None\", \"\"], \"date_updated\": [\"None\", \"2026-05-15 03:25:49.579865\"], \"annual_demand\": [\"None\", \"1000\"], \"reorder_point\": [\"None\", \"10\"], \"registration_logs\": [\"None\", \"product_registration.ProductRegistrationLog.None\"], \"abc_classification\": [\"None\", \"U\"], \"actual_sales_count\": [\"None\", \"0\"], \"manual_annual_demand\": [\"None\", \"0\"]}','2026-05-15 03:25:49.638554',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(169,'21',21,' Alcohol (HAT)',1,'{\"abc_classification\": [\"U\", \"A\"]}','2026-05-15 03:26:01.337754',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(170,'14',14,' Boysen Paint Thinner 1L ( MT)',1,'{\"abc_classification\": [\"B\", \"C\"]}','2026-05-15 03:26:01.390970',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(171,'21',21,' Alcohol (HAT)',1,'{\"quantity\": [\"50\", \"45\"]}','2026-05-15 03:30:37.637842',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(172,'14',14,' Boysen Paint Thinner 1L ( MT)',1,'{\"quantity\": [\"57\", \"56\"]}','2026-05-15 03:32:37.604889',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(173,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"2\", \"102\"]}','2026-05-15 08:45:16.692242',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(174,'5',5,'PO-09D5DE - Pioneer Adhesives Inc.',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-15 08:45:16.761307',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(175,'10',10,' Omni LED Bulb 9W Daylight   (EL)',1,'{\"quantity\": [\"74\", \"76\"]}','2026-05-15 08:45:19.806883',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(176,'6',6,'PO-CCD6F2 - Yatai Int\'l',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-15 08:45:19.880281',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(177,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"102\", \"22\"]}','2026-05-15 08:46:31.706329',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(178,'9',9,'test (Admin)',0,'{\"id\": [\"None\", \"9\"], \"role\": [\"None\", \"Admin\"], \"backups\": [\"None\", \"maintenance.BackupRecord.None\"], \"reports\": [\"None\", \"reports_analytics.Report.None\"], \"is_staff\": [\"None\", \"False\"], \"payments\": [\"None\", \"billing_payment.Payment.None\"], \"restores\": [\"None\", \"maintenance.RestoreRecord.None\"], \"searches\": [\"None\", \"search.SearchLog.None\"], \"username\": [\"None\", \"test\"], \"full_name\": [\"None\", \"test\"], \"is_active\": [\"None\", \"True\"], \"date_created\": [\"None\", \"2026-05-15 10:17:31.639023\"], \"is_superuser\": [\"None\", \"False\"], \"transactions\": [\"None\", \"point_of_sale.Transaction.None\"], \"notifications\": [\"None\", \"notifications.Notification.None\"], \"security_logs\": [\"None\", \"security.ActivityLog.None\"], \"manual_articles\": [\"None\", \"user_manual.ManualArticle.None\"], \"manual_sections\": [\"None\", \"user_manual.ManualSection.None\"]}','2026-05-15 10:17:32.122308',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(179,'9',9,'test (Admin)',1,'{\"is_staff\": [\"False\", \"True\"], \"is_superuser\": [\"False\", \"True\"]}','2026-05-15 10:17:32.170327',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(180,'9',9,'test (Admin)',2,'{\"id\": [\"9\", \"None\"], \"role\": [\"Admin\", \"None\"], \"backups\": [\"maintenance.BackupRecord.None\", \"None\"], \"reports\": [\"reports_analytics.Report.None\", \"None\"], \"is_staff\": [\"True\", \"None\"], \"payments\": [\"billing_payment.Payment.None\", \"None\"], \"restores\": [\"maintenance.RestoreRecord.None\", \"None\"], \"searches\": [\"search.SearchLog.None\", \"None\"], \"username\": [\"test\", \"None\"], \"full_name\": [\"test\", \"None\"], \"is_active\": [\"True\", \"None\"], \"date_created\": [\"2026-05-15 10:17:31.639023\", \"None\"], \"is_superuser\": [\"True\", \"None\"], \"transactions\": [\"point_of_sale.Transaction.None\", \"None\"], \"notifications\": [\"notifications.Notification.None\", \"None\"], \"security_logs\": [\"security.ActivityLog.None\", \"None\"], \"manual_articles\": [\"user_manual.ManualArticle.None\", \"None\"], \"manual_sections\": [\"user_manual.ManualSection.None\", \"None\"]}','2026-05-15 10:18:30.181248',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(181,'10',10,'test4 (Employee)',0,'{\"id\": [\"None\", \"10\"], \"role\": [\"None\", \"Employee\"], \"backups\": [\"None\", \"maintenance.BackupRecord.None\"], \"reports\": [\"None\", \"reports_analytics.Report.None\"], \"is_staff\": [\"None\", \"False\"], \"payments\": [\"None\", \"billing_payment.Payment.None\"], \"restores\": [\"None\", \"maintenance.RestoreRecord.None\"], \"searches\": [\"None\", \"search.SearchLog.None\"], \"username\": [\"None\", \"test4\"], \"full_name\": [\"None\", \"test4\"], \"is_active\": [\"None\", \"True\"], \"date_created\": [\"None\", \"2026-05-15 10:18:47.820921\"], \"is_superuser\": [\"None\", \"False\"], \"transactions\": [\"None\", \"point_of_sale.Transaction.None\"], \"notifications\": [\"None\", \"notifications.Notification.None\"], \"security_logs\": [\"None\", \"security.ActivityLog.None\"], \"manual_articles\": [\"None\", \"user_manual.ManualArticle.None\"], \"manual_sections\": [\"None\", \"user_manual.ManualSection.None\"]}','2026-05-15 10:18:48.316928',1,6,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(182,'22',22,' C2 (HW)',0,'{\"id\": [\"None\", \"22\"], \"price\": [\"None\", \"25\"], \"category\": [\"None\", \"9\"], \"quantity\": [\"None\", \"89\"], \"supplier\": [\"None\", \"7\"], \"item_name\": [\"None\", \" C2\"], \"unit_cost\": [\"None\", \"20\"], \"barcode_id\": [\"None\", \"4800016052040\"], \"date_added\": [\"None\", \"2026-05-15 10:39:35.688625\"], \"product_id\": [\"None\", \"HW008\"], \"sold_items\": [\"None\", \"point_of_sale.TransactionItem.None\"], \"description\": [\"None\", \"\"], \"date_updated\": [\"None\", \"2026-05-15 10:39:35.698500\"], \"annual_demand\": [\"None\", \"3000\"], \"reorder_point\": [\"None\", \"10\"], \"registration_logs\": [\"None\", \"product_registration.ProductRegistrationLog.None\"], \"abc_classification\": [\"None\", \"U\"], \"actual_sales_count\": [\"None\", \"0\"], \"manual_annual_demand\": [\"None\", \"0\"]}','2026-05-15 10:39:35.755009',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(183,'8',8,' Common Wire Nails 2\" (1kg)   (HW)',1,'{\"abc_classification\": [\"B\", \"A\"]}','2026-05-15 10:40:44.282483',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(184,'22',22,' C2 (HW)',1,'{\"abc_classification\": [\"U\", \"B\"]}','2026-05-15 10:40:44.301600',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(185,'17',17,' Bostik No More Nails 320g  ( MT)',1,'{\"quantity\": [\"20\", \"5\"]}','2026-05-15 10:47:15.784120',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(186,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"22\", \"18\"]}','2026-05-15 10:48:02.263998',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(187,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"18\", \"9\"]}','2026-05-15 10:48:31.840685',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(188,'7',7,'PO-DA3534 - Pioneer Adhesives Inc.',0,'{\"id\": [\"None\", \"7\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"11\"], \"po_number\": [\"None\", \"PO-DA3534\"], \"order_date\": [\"None\", \"2026-05-15 10:49:58.249196\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-15\"]}','2026-05-15 10:49:58.306535',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(189,'7',7,'PO-DA3534 - Pioneer Adhesives Inc.',1,'{\"total_amount\": [\"0.00\", \"14850.00\"]}','2026-05-15 10:49:58.328280',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(190,'8',8,'PO-E22C42 - Bostik Philippines',0,'{\"id\": [\"None\", \"8\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"15\"], \"po_number\": [\"None\", \"PO-E22C42\"], \"order_date\": [\"None\", \"2026-05-15 10:50:14.676653\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-15\"]}','2026-05-15 10:50:14.731214',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(191,'8',8,'PO-E22C42 - Bostik Philippines',1,'{\"total_amount\": [\"0.00\", \"6300.00\"]}','2026-05-15 10:50:14.747431',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(192,'13',13,' Pioneer Epoxy Clay Aqua ( MT)',1,'{\"quantity\": [\"9\", \"119\"]}','2026-05-15 10:50:31.915087',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(193,'7',7,'PO-DA3534 - Pioneer Adhesives Inc.',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-15 10:50:31.980903',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(194,'17',17,' Bostik No More Nails 320g  ( MT)',1,'{\"quantity\": [\"5\", \"35\"]}','2026-05-15 10:50:36.000785',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(195,'8',8,'PO-E22C42 - Bostik Philippines',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-15 10:50:36.067160',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(196,'17',17,' Bostik No More Nails 320g  ( MT)',1,'{\"quantity\": [\"35\", \"30\"]}','2026-05-15 11:01:37.310176',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(197,'17',17,' Bostik No More Nails 320g  ( MT)',1,'{\"quantity\": [\"30\", \"5\"]}','2026-05-15 11:04:45.812353',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(198,'21',21,' Alcohol (HAT)',1,'{\"quantity\": [\"45\", \"5\"]}','2026-05-15 11:04:45.830180',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(199,'9',9,'PO-720273 - Bostik Philippines',0,'{\"id\": [\"None\", \"9\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"15\"], \"po_number\": [\"None\", \"PO-720273\"], \"order_date\": [\"None\", \"2026-05-15 11:06:12.824910\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-15\"]}','2026-05-15 11:06:12.866202',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(200,'9',9,'PO-720273 - Bostik Philippines',1,'{\"total_amount\": [\"0.00\", \"3150.00\"]}','2026-05-15 11:06:12.883982',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(201,'10',10,'PO-BA380B - ABC',0,'{\"id\": [\"None\", \"10\"], \"items\": [\"None\", \"inventory.PurchaseOrderItem.None\"], \"status\": [\"None\", \"pending\"], \"supplier\": [\"None\", \"1\"], \"po_number\": [\"None\", \"PO-BA380B\"], \"order_date\": [\"None\", \"2026-05-15 11:09:05.467001\"], \"total_amount\": [\"None\", \"0.0\"], \"expected_delivery\": [\"None\", \"2026-05-22\"]}','2026-05-15 11:09:05.514468',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(202,'10',10,'PO-BA380B - ABC',1,'{\"total_amount\": [\"0.00\", \"1350.00\"]}','2026-05-15 11:09:05.530830',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(203,'21',21,' Alcohol (HAT)',1,'{\"quantity\": [\"5\", \"3\"]}','2026-05-21 09:22:10.733548',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(204,'17',17,' Bostik No More Nails 320g  ( MT)',1,'{\"quantity\": [\"5\", \"20\"], \"reorder_point\": [\"10\", \"0\"]}','2026-05-23 14:55:35.567735',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(205,'9',9,'PurchaseOrder object (9)',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-23 14:55:35.587378',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(206,'21',21,' Alcohol (HAT)',1,'{\"quantity\": [\"3\", \"18\"], \"reorder_point\": [\"10\", \"0\"]}','2026-05-23 14:55:40.683533',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),(207,'10',10,'PurchaseOrder object (10)',1,'{\"status\": [\"pending\", \"received\"]}','2026-05-23 14:55:40.701303',1,33,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL);
/*!40000 ALTER TABLE `auditlog_logentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add User',6,'add_user'),(22,'Can change User',6,'change_user'),(23,'Can delete User',6,'delete_user'),(24,'Can view User',6,'view_user'),(25,'Can add category',7,'add_category'),(26,'Can change category',7,'change_category'),(27,'Can delete category',7,'delete_category'),(28,'Can view category',7,'view_category'),(29,'Can add inventory item',8,'add_inventoryitem'),(30,'Can change inventory item',8,'change_inventoryitem'),(31,'Can delete inventory item',8,'delete_inventoryitem'),(32,'Can view inventory item',8,'view_inventoryitem'),(33,'Can add stock adjustment',9,'add_stockadjustment'),(34,'Can change stock adjustment',9,'change_stockadjustment'),(35,'Can delete stock adjustment',9,'delete_stockadjustment'),(36,'Can view stock adjustment',9,'view_stockadjustment'),(37,'Can add supplier',10,'add_supplier'),(38,'Can change supplier',10,'change_supplier'),(39,'Can delete supplier',10,'delete_supplier'),(40,'Can view supplier',10,'view_supplier'),(41,'Can add csv import log',11,'add_csvimportlog'),(42,'Can change csv import log',11,'change_csvimportlog'),(43,'Can delete csv import log',11,'delete_csvimportlog'),(44,'Can view csv import log',11,'view_csvimportlog'),(45,'Can add product registration log',12,'add_productregistrationlog'),(46,'Can change product registration log',12,'change_productregistrationlog'),(47,'Can delete product registration log',12,'delete_productregistrationlog'),(48,'Can view product registration log',12,'view_productregistrationlog'),(49,'Can add transaction',13,'add_transaction'),(50,'Can change transaction',13,'change_transaction'),(51,'Can delete transaction',13,'delete_transaction'),(52,'Can view transaction',13,'view_transaction'),(53,'Can add transaction item',14,'add_transactionitem'),(54,'Can change transaction item',14,'change_transactionitem'),(55,'Can delete transaction item',14,'delete_transactionitem'),(56,'Can view transaction item',14,'view_transactionitem'),(57,'Can add payment',15,'add_payment'),(58,'Can change payment',15,'change_payment'),(59,'Can delete payment',15,'delete_payment'),(60,'Can view payment',15,'view_payment'),(61,'Can add receipt',16,'add_receipt'),(62,'Can change receipt',16,'change_receipt'),(63,'Can delete receipt',16,'delete_receipt'),(64,'Can view receipt',16,'view_receipt'),(65,'Can add report',17,'add_report'),(66,'Can change report',17,'change_report'),(67,'Can delete report',17,'delete_report'),(68,'Can view report',17,'view_report'),(69,'Can add activity log',18,'add_activitylog'),(70,'Can change activity log',18,'change_activitylog'),(71,'Can delete activity log',18,'delete_activitylog'),(72,'Can view activity log',18,'view_activitylog'),(73,'Can add notification',19,'add_notification'),(74,'Can change notification',19,'change_notification'),(75,'Can delete notification',19,'delete_notification'),(76,'Can view notification',19,'view_notification'),(77,'Can add backup record',20,'add_backuprecord'),(78,'Can change backup record',20,'change_backuprecord'),(79,'Can delete backup record',20,'delete_backuprecord'),(80,'Can view backup record',20,'view_backuprecord'),(81,'Can add restore record',21,'add_restorerecord'),(82,'Can change restore record',21,'change_restorerecord'),(83,'Can delete restore record',21,'delete_restorerecord'),(84,'Can view restore record',21,'view_restorerecord'),(85,'Can add search log',22,'add_searchlog'),(86,'Can change search log',22,'change_searchlog'),(87,'Can delete search log',22,'delete_searchlog'),(88,'Can view search log',22,'view_searchlog'),(89,'Can add manual section',23,'add_manualsection'),(90,'Can change manual section',23,'change_manualsection'),(91,'Can delete manual section',23,'delete_manualsection'),(92,'Can view manual section',23,'view_manualsection'),(93,'Can add manual article',24,'add_manualarticle'),(94,'Can change manual article',24,'change_manualarticle'),(95,'Can delete manual article',24,'delete_manualarticle'),(96,'Can view manual article',24,'view_manualarticle'),(97,'Can view Activity Log',25,'view_activitylog'),(98,'Can add Employee Profile',26,'add_employeeprofile'),(99,'Can change Employee Profile',26,'change_employeeprofile'),(100,'Can delete Employee Profile',26,'delete_employeeprofile'),(101,'Can view Employee Profile',26,'view_employeeprofile'),(102,'Can add log entry',27,'add_logentry'),(103,'Can change log entry',27,'change_logentry'),(104,'Can delete log entry',27,'delete_logentry'),(105,'Can view log entry',27,'view_logentry'),(106,'Can add cart item',28,'add_cartitem'),(107,'Can change cart item',28,'change_cartitem'),(108,'Can delete cart item',28,'delete_cartitem'),(109,'Can view cart item',28,'view_cartitem'),(110,'Can add customer',29,'add_customer'),(111,'Can change customer',29,'change_customer'),(112,'Can delete customer',29,'delete_customer'),(113,'Can view customer',29,'view_customer'),(114,'Can add invoice',30,'add_invoice'),(115,'Can change invoice',30,'change_invoice'),(116,'Can delete invoice',30,'delete_invoice'),(117,'Can view invoice',30,'view_invoice'),(118,'Can add invoice payment',31,'add_invoicepayment'),(119,'Can change invoice payment',31,'change_invoicepayment'),(120,'Can delete invoice payment',31,'delete_invoicepayment'),(121,'Can view invoice payment',31,'view_invoicepayment'),(122,'Can add purchase order item',32,'add_purchaseorderitem'),(123,'Can change purchase order item',32,'change_purchaseorderitem'),(124,'Can delete purchase order item',32,'delete_purchaseorderitem'),(125,'Can view purchase order item',32,'view_purchaseorderitem'),(126,'Can add purchase order',33,'add_purchaseorder'),(127,'Can change purchase order',33,'change_purchaseorder'),(128,'Can delete purchase order',33,'delete_purchaseorder'),(129,'Can view purchase order',33,'view_purchaseorder'),(130,'Can add invoice item',34,'add_invoiceitem'),(131,'Can change invoice item',34,'change_invoiceitem'),(132,'Can delete invoice item',34,'delete_invoiceitem'),(133,'Can view invoice item',34,'view_invoiceitem'),(134,'Can add sales return',35,'add_salesreturn'),(135,'Can change sales return',35,'change_salesreturn'),(136,'Can delete sales return',35,'delete_salesreturn'),(137,'Can view sales return',35,'view_salesreturn'),(138,'Can add sales return item',36,'add_salesreturnitem'),(139,'Can change sales return item',36,'change_salesreturnitem'),(140,'Can delete sales return item',36,'delete_salesreturnitem'),(141,'Can view sales return item',36,'view_salesreturnitem'),(142,'Can add expense',37,'add_expense'),(143,'Can change expense',37,'change_expense'),(144,'Can delete expense',37,'delete_expense'),(145,'Can view expense',37,'view_expense');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_records`
--

DROP TABLE IF EXISTS `backup_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `backup_type` varchar(10) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size_kb` int unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `error_message` longtext NOT NULL,
  `date_created` datetime(6) NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backup_records_created_by_id_104a565b_fk_users_id` (`created_by_id`),
  CONSTRAINT `backup_records_created_by_id_104a565b_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `security_user` (`id`),
  CONSTRAINT `backup_records_chk_1` CHECK ((`file_size_kb` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_records`
--

LOCK TABLES `backup_records` WRITE;
/*!40000 ALTER TABLE `backup_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_payment_invoiceitem`
--

DROP TABLE IF EXISTS `billing_payment_invoiceitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_payment_invoiceitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `invoice_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billing_payment_invoiceitem_invoice_id_f1c1e7df_fk_invoices_id` (`invoice_id`),
  CONSTRAINT `billing_payment_invoiceitem_invoice_id_f1c1e7df_fk_invoices_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_payment_invoiceitem`
--

LOCK TABLES `billing_payment_invoiceitem` WRITE;
/*!40000 ALTER TABLE `billing_payment_invoiceitem` DISABLE KEYS */;
INSERT INTO `billing_payment_invoiceitem` VALUES (1,' Boysen Paint Thinner 1L',1,125.00,125.00,2),(2,' Common Wire Nails 2\" (1kg)  ',1,85.00,85.00,2),(3,' Bostik No More Nails 320g',1,295.00,295.00,2),(12,' Common Wire Nails 2\" (1kg)  ',1,85.00,85.00,4),(13,' Boysen Paint Thinner 1L',3,125.00,375.00,4),(14,' Bostik No More Nails 320g',3,295.00,885.00,4),(15,' Mighty Bond Instant Glue 3g',3,65.00,195.00,4),(16,' Omni LED Bulb 9W Daylight  ',2,100.00,200.00,4),(17,' Pioneer Epoxy Clay Aqua',1,180.00,180.00,4),(18,' Tox with Screws Set 6mm (100s) ',1,55.00,55.00,4),(19,' WD-40 Multi-Use 412g    ',1,320.00,320.00,4),(20,' Green Cross Alcohol',1,150.00,150.00,4),(21,' Boysen Paint Thinner 1L',1,125.00,125.00,5),(22,' Bostik No More Nails 320g',1,295.00,295.00,5),(23,' Mighty Bond Instant Glue 3g',1,65.00,65.00,5),(24,' Omni LED Bulb 9W Daylight  ',2,100.00,200.00,5),(25,' Common Wire Nails 2\" (1kg)  ',2,85.00,170.00,5),(26,' Pioneer Epoxy Clay Aqua',37,180.00,6660.00,6),(27,' Pioneer Epoxy Clay Aqua',1,180.00,180.00,7),(28,' 3M Scotch-Brite Heavy Duty',2,45.00,90.00,8),(29,' Pioneer Epoxy Clay Aqua',18,180.00,3240.00,9),(30,' Alcohol',5,100.00,500.00,10),(31,' Boysen Paint Thinner 1L',1,125.00,125.00,11),(32,' Pioneer Epoxy Clay Aqua',80,180.00,14400.00,12),(33,' Bostik No More Nails 320g ',15,295.00,4425.00,13),(34,' Pioneer Epoxy Clay Aqua',4,180.00,720.00,14),(35,' Pioneer Epoxy Clay Aqua',9,180.00,1620.00,15),(36,' Bostik No More Nails 320g ',5,295.00,1475.00,16),(37,' Bostik No More Nails 320g ',25,295.00,7375.00,17),(38,' Alcohol',40,100.00,4000.00,17),(39,' Alcohol',2,100.00,200.00,18);
/*!40000 ALTER TABLE `billing_payment_invoiceitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_payment_salesreturn`
--

DROP TABLE IF EXISTS `billing_payment_salesreturn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_payment_salesreturn` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `return_id` varchar(50) NOT NULL,
  `reason` longtext NOT NULL,
  `total_refund` decimal(10,2) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `transaction_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_id` (`return_id`),
  KEY `billing_payment_sale_transaction_id_f82da8fd_fk_pos_trans` (`transaction_id`),
  CONSTRAINT `billing_payment_sale_transaction_id_f82da8fd_fk_pos_trans` FOREIGN KEY (`transaction_id`) REFERENCES `pos_transactions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_payment_salesreturn`
--

LOCK TABLES `billing_payment_salesreturn` WRITE;
/*!40000 ALTER TABLE `billing_payment_salesreturn` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_payment_salesreturn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_payment_salesreturnitem`
--

DROP TABLE IF EXISTS `billing_payment_salesreturnitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_payment_salesreturnitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` int unsigned NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `product_id` bigint NOT NULL,
  `sales_return_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billing_payment_sale_product_id_b3e34d7a_fk_inventory` (`product_id`),
  KEY `billing_payment_sale_sales_return_id_3b623699_fk_billing_p` (`sales_return_id`),
  CONSTRAINT `billing_payment_sale_product_id_b3e34d7a_fk_inventory` FOREIGN KEY (`product_id`) REFERENCES `inventory` (`id`),
  CONSTRAINT `billing_payment_sale_sales_return_id_3b623699_fk_billing_p` FOREIGN KEY (`sales_return_id`) REFERENCES `billing_payment_salesreturn` (`id`),
  CONSTRAINT `billing_payment_salesreturnitem_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_payment_salesreturnitem`
--

LOCK TABLES `billing_payment_salesreturnitem` WRITE;
/*!40000 ALTER TABLE `billing_payment_salesreturnitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_payment_salesreturnitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `prefix` varchar(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `prefix` (`prefix`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (5,'Construction','','2026-05-07 13:58:56.258592','CO'),(7,'Maintenance','','2026-05-07 14:00:35.107425',' MT'),(8,'Hand Tools','','2026-05-07 14:02:01.166545','HAT'),(9,'Hardware','','2026-05-07 14:02:54.596770','HW'),(11,'Electrical','','2026-05-07 14:04:19.118077','EL');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `csv_import_logs`
--

DROP TABLE IF EXISTS `csv_import_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `csv_import_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `total_rows` int unsigned NOT NULL,
  `success_rows` int unsigned NOT NULL,
  `failed_rows` int unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `error_details` longtext NOT NULL,
  `imported_at` datetime(6) NOT NULL,
  `imported_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `csv_import_logs_imported_by_id_f14b1587_fk_users_id` (`imported_by_id`),
  CONSTRAINT `csv_import_logs_imported_by_id_f14b1587_fk_users_id` FOREIGN KEY (`imported_by_id`) REFERENCES `security_user` (`id`),
  CONSTRAINT `csv_import_logs_chk_1` CHECK ((`total_rows` >= 0)),
  CONSTRAINT `csv_import_logs_chk_2` CHECK ((`success_rows` >= 0)),
  CONSTRAINT `csv_import_logs_chk_3` CHECK ((`failed_rows` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `csv_import_logs`
--

LOCK TABLES `csv_import_logs` WRITE;
/*!40000 ALTER TABLE `csv_import_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `csv_import_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `is_credit_customer` tinyint(1) NOT NULL,
  `credit_limit` decimal(12,2) NOT NULL,
  `credit_balance` decimal(12,2) NOT NULL,
  `payment_terms` int NOT NULL,
  `credit_status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'jewelle','09150550064',1,50000.00,1575.00,30,'active');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_users_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `security_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (18,'activity_log','activitylog'),(1,'admin','logentry'),(27,'auditlog','logentry'),(3,'auth','group'),(2,'auth','permission'),(29,'billing_payment','customer'),(30,'billing_payment','invoice'),(34,'billing_payment','invoiceitem'),(31,'billing_payment','invoicepayment'),(15,'billing_payment','payment'),(16,'billing_payment','receipt'),(35,'billing_payment','salesreturn'),(36,'billing_payment','salesreturnitem'),(4,'contenttypes','contenttype'),(7,'inventory','category'),(8,'inventory','inventoryitem'),(33,'inventory','purchaseorder'),(32,'inventory','purchaseorderitem'),(9,'inventory','stockadjustment'),(10,'inventory','supplier'),(20,'maintenance','backuprecord'),(21,'maintenance','restorerecord'),(19,'notifications','notification'),(28,'point_of_sale','cartitem'),(13,'point_of_sale','transaction'),(14,'point_of_sale','transactionitem'),(11,'product_registration','csvimportlog'),(12,'product_registration','productregistrationlog'),(37,'reports_analytics','expense'),(17,'reports_analytics','report'),(22,'search','searchlog'),(25,'security','activitylog'),(26,'security','employeeprofile'),(6,'security','user'),(5,'sessions','session'),(24,'user_manual','manualarticle'),(23,'user_manual','manualsection');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2026-05-01 13:40:52.522877'),(2,'contenttypes','0002_remove_content_type_name','2026-05-01 13:40:52.696173'),(3,'auth','0001_initial','2026-05-01 13:40:53.136109'),(4,'auth','0002_alter_permission_name_max_length','2026-05-01 13:40:53.221836'),(5,'auth','0003_alter_user_email_max_length','2026-05-01 13:40:53.231944'),(6,'auth','0004_alter_user_username_opts','2026-05-01 13:40:53.242156'),(7,'auth','0005_alter_user_last_login_null','2026-05-01 13:40:53.251912'),(8,'auth','0006_require_contenttypes_0002','2026-05-01 13:40:53.256430'),(9,'auth','0007_alter_validators_add_error_messages','2026-05-01 13:40:53.269311'),(10,'auth','0008_alter_user_username_max_length','2026-05-01 13:40:53.281536'),(11,'auth','0009_alter_user_last_name_max_length','2026-05-01 13:40:53.296536'),(12,'auth','0010_alter_group_name_max_length','2026-05-01 13:40:53.323035'),(13,'auth','0011_update_proxy_permissions','2026-05-01 13:40:53.335466'),(14,'auth','0012_alter_user_first_name_max_length','2026-05-01 13:40:53.345277'),(15,'security','0001_initial','2026-05-01 13:40:53.786503'),(16,'activity_log','0001_initial','2026-05-01 13:40:53.811450'),(17,'activity_log','0002_initial','2026-05-01 13:40:53.949877'),(18,'admin','0001_initial','2026-05-01 13:40:54.125078'),(19,'admin','0002_logentry_remove_auto_add','2026-05-01 13:40:54.136436'),(20,'admin','0003_logentry_add_action_flag_choices','2026-05-01 13:40:54.146690'),(21,'point_of_sale','0001_initial','2026-05-01 13:40:54.205394'),(22,'billing_payment','0001_initial','2026-05-01 13:40:54.257683'),(23,'billing_payment','0002_initial','2026-05-01 13:40:54.482400'),(24,'inventory','0001_initial','2026-05-01 13:40:54.596872'),(25,'inventory','0002_initial','2026-05-01 13:40:55.179695'),(26,'maintenance','0001_initial','2026-05-01 13:40:55.225583'),(27,'maintenance','0002_initial','2026-05-01 13:40:55.465184'),(28,'notifications','0001_initial','2026-05-01 13:40:55.492962'),(29,'notifications','0002_initial','2026-05-01 13:40:55.638282'),(30,'point_of_sale','0002_initial','2026-05-01 13:40:55.919879'),(31,'product_registration','0001_initial','2026-05-01 13:40:55.964164'),(32,'product_registration','0002_initial','2026-05-01 13:40:56.270239'),(33,'reports_analytics','0001_initial','2026-05-01 13:40:56.292137'),(34,'reports_analytics','0002_initial','2026-05-01 13:40:56.386344'),(35,'search','0001_initial','2026-05-01 13:40:56.411279'),(36,'search','0002_initial','2026-05-01 13:40:56.527229'),(37,'sessions','0001_initial','2026-05-01 13:40:56.567529'),(38,'user_manual','0001_initial','2026-05-01 13:40:56.833443'),(39,'security','0002_alter_user_options_alter_user_full_name_and_more','2026-05-01 16:25:27.164427'),(40,'inventory','0003_category_prefix_alter_inventoryitem_product_id','2026-05-07 13:24:16.064164'),(41,'inventory','0004_supplier_supplier_id_alter_supplier_name','2026-05-07 13:24:16.227707'),(42,'inventory','0005_remove_stockadjustment_adjusted_by_and_more','2026-05-07 13:24:17.028364'),(43,'inventory','0006_remove_inventoryitem_added_by_and_more','2026-05-07 13:24:17.308202'),(44,'inventory','0007_inventoryitem_actual_sales_count_and_more','2026-05-07 13:24:17.512949'),(45,'auditlog','0001_initial','2026-05-08 06:11:15.925243'),(46,'auditlog','0002_auto_support_long_primary_keys','2026-05-08 06:11:16.066772'),(47,'auditlog','0003_logentry_remote_addr','2026-05-08 06:11:16.189771'),(48,'auditlog','0004_logentry_detailed_object_repr','2026-05-08 06:11:16.273284'),(49,'auditlog','0005_logentry_additional_data_verbose_name','2026-05-08 06:11:16.297099'),(50,'auditlog','0006_object_pk_index','2026-05-08 06:11:16.398953'),(51,'auditlog','0007_object_pk_type','2026-05-08 06:11:16.414120'),(52,'auditlog','0008_action_index','2026-05-08 06:11:16.451277'),(53,'auditlog','0009_alter_logentry_additional_data','2026-05-08 06:11:16.471839'),(54,'auditlog','0010_alter_logentry_timestamp','2026-05-08 06:11:16.514067'),(55,'auditlog','0011_logentry_serialized_data','2026-05-08 06:11:16.600357'),(56,'auditlog','0012_add_logentry_action_access','2026-05-08 06:11:16.621547'),(57,'auditlog','0013_alter_logentry_timestamp','2026-05-08 06:11:16.641845'),(58,'auditlog','0014_logentry_cid','2026-05-08 06:11:16.779201'),(59,'auditlog','0015_alter_logentry_changes','2026-05-08 06:11:17.014059'),(60,'auditlog','0016_logentry_remote_port','2026-05-08 06:11:17.107364'),(61,'auditlog','0017_add_actor_email','2026-05-08 06:11:17.197208'),(62,'point_of_sale','0003_transaction_payment_method','2026-05-08 07:06:07.028998'),(63,'point_of_sale','0004_alter_transactionitem_transaction_cartitem','2026-05-08 11:43:05.209318'),(64,'point_of_sale','0005_transaction_reference_number','2026-05-08 11:43:05.266058'),(65,'billing_payment','0003_customer_invoice_invoicepayment','2026-05-08 14:03:43.302559'),(66,'point_of_sale','0006_transaction_customer_and_more','2026-05-08 14:03:43.477147'),(67,'point_of_sale','0007_alter_transaction_status_delete_cartitem','2026-05-09 03:53:42.642180'),(68,'inventory','0008_purchaseorder_purchaseorderitem','2026-05-10 13:20:21.710229'),(69,'inventory','0009_supplier_is_active','2026-05-10 13:57:25.264649'),(70,'billing_payment','0004_invoice_source_alter_invoice_balance_due_and_more','2026-05-11 07:23:02.814879'),(71,'billing_payment','0005_alter_invoice_customer','2026-05-11 07:23:03.018177'),(72,'billing_payment','0006_salesreturn_salesreturnitem','2026-05-11 07:23:03.321007'),(73,'reports_analytics','0003_expense','2026-05-11 07:58:13.414476'),(74,'activity_log','0003_delete_activitylog','2026-05-11 09:29:55.398951'),(75,'notifications','0003_alter_notification_notification_type','2026-05-12 12:37:18.302826'),(76,'notifications','0004_alter_notification_notification_type','2026-05-12 12:37:18.402133'),(77,'notifications','0005_notification_action_url','2026-05-12 12:37:18.514007'),(78,'inventory','0010_inventoryitem_average_daily_sales_and_more','2026-05-23 14:54:20.691654');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('022fjpxoik62g31u78x7fb7w6o91jumv','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJYjv:r1uI36GCp9mbT2nprDAj2rRXPyqH-1b_GXelnWhZnQk','2026-05-03 23:28:15.421726'),('0ip8lel1s6u2gfgy8kw2i0dsu81s7poh','eyJyZXNldF91c2VybmFtZSI6InRlc3Q0Iiwia2V5X3ZlcmlmaWVkIjp0cnVlfQ:1wNpeW:pqwjwK7LA8X6g1qCDOxMx9WB7RZEZXz3Lm5-b8pVNgg','2026-05-15 18:20:20.436471'),('11omu9sz5e4hvsbvyp8e0o15p075xrbt','.eJxVjEEOwiAQRe_C2pCAdAZcuvcMZGCmUjWQlHbVeHdt0oVu_3vvbyrSupS4dpnjxOqijDr9bonyU-oO-EH13nRudZmnpHdFH7TrW2N5XQ_376BQL98aLTL5s4B3AZxD8QQCbHHwCRIJUHJOYBzQZQiGbUBAYzOPwWdGUe8P1Xw31w:1wLH7I:rgceLDdJ5gWZe-GeztCEGlk2AFGwuHEKWV9Be53FKK4','2026-05-08 17:03:28.949544'),('1492d782ywe31gwxhw934hyzjk13t8nl','.eJxVjEEOwiAQRe_C2pAODJS6dO8ZyMCAVA0kpV0Z765NutDtf-_9l_C0rcVvPS1-ZnEWIE6_W6D4SHUHfKd6azK2ui5zkLsiD9rltXF6Xg7376BQL98aAYMNLhPhMNIUNILJMaSRIxgkox1CUoonTmiU0xAHygyWsmXlgMT7A-oLOBo:1wJDYE:UjyRehlWfF_DU1wpvcTxs6YKyfRr_oWVPzEodS1OUyU','2026-05-03 00:50:46.812560'),('2gw324y202lpwgctekekl6iikdml18ig','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJY2B:jyk5TjSoETa5RE0JDX8-8VlLaGWB4PMzXvTWLgGEYYE','2026-05-03 22:43:03.679889'),('2pbk9wr0t2zn2igh15bbtig4wxbbytxv','.eJxVjsEOwiAQRP-FsyGU1i149N5vILsstaiBBOjJ-O-2pge9zpt5mZdwuLbFrTUUF1lcRCdOvxmhf4S0A75jumXpc2olktwr8qBVTpnD83p0_wQL1mVb92ipnwFmBgsAgzekFNHZI88wBCZS1I8UzM4ZlVZW02iMNdBpoLBJW8FU0beY0_cqjO8Pqn4_Kg:1wQnkj:_mYsIowt2E4WMPKWXPA0MrRJHVXIb052i3sIRihdEW0','2026-05-23 22:55:01.742613'),('4axwurhldxch1r9u4uh2y5v6el2p0yvh','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIn0:1wJBkX:Hy1LDtPUcmGD9Ev1bvudZIG24_9zIkomBuR59H0GqK8','2026-05-02 22:55:21.674627'),('5ohd5xio9afnyxp9p4gmy4l2a1emf39b','.eJxVjMsOgjAQRf9l1oSUUgjDkqWJuvADmj6mUh8laYuJMf67YNiwPefc-4FIibKcE8WgngQ9HIbL-QQF3OktXxS982Shz3GmAqSa8_iPpV8gVLBjWpk7hVXYmwrXqTRTyNHrck3KzabyOFl6DFu7OxhVGpc1IUdiTc11ZXXTOsGcFmTrqkNmSRnUrUHiDAU6auq209aJDlEJrtAxA98f2C1H9Q:1wJDBL:326N61tON2titPb2MNS32lLBZBr6TDwEEcjRuUfsqL4','2026-05-03 00:27:07.389694'),('5rvpvh45kd4h79jcl0o0np08r7o1rt4q','eyJyZXNldF91c2VybmFtZSI6InRlc3Q0Iiwia2V5X3ZlcmlmaWVkIjp0cnVlfQ:1wNq6S:KeT0Xy_iP500TDCRcG3g2eTvRiJDXQDnH7oSRdMkH_A','2026-05-15 18:49:12.490554'),('83dmrryo9zmaoqm6ujblgiezpdnblolx','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJYcI:diPb-9YdJNzEbYvF923zJevBqLN7hUktK5aG8w5wNuM','2026-05-03 23:20:22.949105'),('b1b2tika3hoegcfwkgp45ywfk9inqqtd','.eJxVjsEOwiAQRP-FsyGU4hY8eu83kF2WWtRAUujJ-O-2pge9zpt5mZfwuLbZrzUuPrG4iE6cfjPC8Ih5B3zHfCsylNyWRHKvyINWORaOz-vR_RPMWOdt3aOjfgKYGBwAmGBJKaJzQJ7ARCZS1A8U7c4ZlVZO02Cts9BpoLhJ24K5Ymip5O9VMO8Pqng_Jw:1wNqLY:FPHbpTSI-zaJzWff0ALICx9nVxzByINNyTrztXq5QJk','2026-05-15 19:04:48.143480'),('do7f7jemmhmfdpkv47xq2x7pftbrminr','.eJxVjsEOwiAQRP-FsyGU4hY8eu83kF2WWtRAUujJ-O-2pge9zpt5mZfwuLbZrzUuPrG4iE6cfjPC8Ih5B3zHfCsylNyWRHKvyINWORaOz-vR_RPMWOdt3aOjfgKYGBwAmGBJKaJzQJ7ARCZS1A8U7c4ZlVZO02Cts9BpoLhJ24K5Ymip5O9VY98fqno_KQ:1wMfVt:AQAatUwLjQh6ksJwR8lPhkeUZjNoAz1zFBswoWXQN5k','2026-05-12 13:18:37.296803'),('ebjk21sqv6wk3ejab6t1bxygcnws9h1c','.eJxVjsEOwiAQRP-FsyG0xS149N5vaHZZkKqBBOjJ-O-2pge9zpt5mZeYcW1xXqsv88LiIjpx-s0I3cOnHfAd0y1Ll1MrC8m9Ig9a5ZTZP69H908QscZtPaClIQAEBgsA2hlSiujskANoz0SKhpG82Tmj6pXtaTTGGuh6IL9JW8FU0bUlp-9Vrd8fqnI_JQ:1wMNVE:vT0PBOJRrwlxiedZS_4ctf6LtXXtQ4Si3p_I674sxOE','2026-05-11 18:04:44.334034'),('fpbj5gduk41noinrefgwe3d7vb2msc7r','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJZ0m:sxYQ_tNPUm0vh_yNWJeupyizoBUK-WoGjcUekeDybgQ','2026-05-03 23:45:40.998790'),('gu8hw7byaj2wxf6x63ugxamshuz52tbl','.eJxVjEEOwiAQRe_C2pCAdAZcuvcMZGCmUjWQlHbVeHdt0oVu_3vvbyrSupS4dpnjxOqijDr9bonyU-oO-EH13nRudZmnpHdFH7TrW2N5XQ_376BQL98aLTL5s4B3AZxD8QQCbHHwCRIJUHJOYBzQZQiGbUBAYzOPwWdGUe8P1Xw31w:1wJZ9b:Y9ni-fQHfW8Q963eCxlm2q10_GhFmBeVXcXCoB466H8','2026-05-03 23:54:47.323455'),('h7qt9jvfpu5sut5l71ouy4wf7siqhx2w','.eJxVjEEOwiAQRe_C2pCAdAZcuvcMZGCmUjWQlHbVeHdt0oVu_3vvbyrSupS4dpnjxOqijDr9bonyU-oO-EH13nRudZmnpHdFH7TrW2N5XQ_376BQL98aLTL5s4B3AZxD8QQCbHHwCRIJUHJOYBzQZQiGbUBAYzOPwWdGUe8P1Xw31w:1wKyj9:zoK7xk8114rbUoNcBogIX5mtUdmc2VOAa9vJinsODiI','2026-05-07 21:25:19.990289'),('jdqe7p1339yjjor7ynb1n9v8ccymmtt4','.eJxVjsEOwiAQRP-FsyFQ6hY8eu83NLss2KqBBOjJ-O-2pge9zpt5mZeYcG3ztNZQpoXFRWhx-s0I_SOkHfAd0y1Ln1MrC8m9Ig9a5Zg5PK9H908wY523tUFHJgJEBgcAvbekFNHZI0foAxMpMgMFu3NG1SnX0WCts6A7oLBJW8FU0bclp-9Vbd4fqmc_IQ:1wLMR5:PcQij7YAkBbdeFc-NVVlVaANGX6tMqlJtgRR8-l-ock','2026-05-08 22:44:15.094512'),('ku3j7ff1bqexl234xm9qa6uc08vc3j3w','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJYCm:7Is2PUuoeTO_N5MhcQiSGMOJLi_wdGOlFf0j0MA-FOs','2026-05-03 22:54:00.158223'),('l7j0ixjzimhwxes6cqqf1x0uyde9warb','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJYxp:X9Czz1wXa4FG0KMis4iDzgYZtNYVVeUSJPLU1ETPaWk','2026-05-03 23:42:37.124682'),('nporex71bisq9loecu9j3eintxwtxas7','.eJxVjMsOgjAQRf9l1oQIfbNkaaIu_IBmoINUtCQtmBjjvwuGDdtzzr0fiJRosnOiGPBJUMGxvl7OkMFAb_ui6DtPDqopzpSBxXnq_7H1CwQDO9ZgO1BYhbtjuI15O4Yp-iZfk3yzKT-Njh711u4Oekz9smbS6FIK4lIgFpoZ5RRjpW5kiyiVJM0aLrRRTGAnONPKaF6a1nTdgWNRwvcHnJRGMg:1wNpby:Gmns2EA05zj_WFlBQARviUDmBosc27MyQ_xdxSOv54g','2026-05-15 18:17:42.872339'),('nyphvelq4uqahdgfavqm7r1b8y2b3d2i','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJZBX:awTGY4EYQdLUrEzxDayyZ-XQRjiK_T6tcFrVr5455wg','2026-05-03 23:56:47.955878'),('qkjjo2sjwn5b81e68ywigp5uxj74xrs4','.eJxVjsEOwiAQRP-FsyG01C149N5vaHZZkKqBBOjJ-O-2pge9zpt5mZeYcW1xXqsv88LiIjpx-s0I3cOnHfAd0y1Ll1MrC8m9Ig9a5ZTZP69H908QscZtrdGSDgCBwQLA4AwpRXR2yAEGz0SK9Eje7JxR9cr2NBpjDXQ9kN-krWCq6NqS0_eqVu8Pqmc_IA:1wLa3H:B7chd2nWPjdNncrFioktpdHl3xe2yt9r_4iW0F5xkVw','2026-05-09 13:16:35.198851'),('rp2eni9gt6v1hvvnicexboi7ljdjxnaq','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJYlV:50JV78hC3QOK08nTDFa5XohadVh8A2giAoOHKzpmfwM','2026-05-03 23:29:53.478836'),('snht9f3x2x8elx0vurdz6hgkkgk2wuwt','.eJxVjEEOwiAQRe_C2pAODJS6dO8ZyMCAVA0kpV0Z765NutDtf-_9l_C0rcVvPS1-ZnEWIE6_W6D4SHUHfKd6azK2ui5zkLsiD9rltXF6Xg7376BQL98aAYMNLhPhMNIUNILJMaSRIxgkox1CUoonTmiU0xAHygyWsmXlgMT7A-oLOBo:1wJDPC:UAtEpV4BAoZX1lo6pDCVTXsOGd7Wn3eDf55wgnK_MKM','2026-05-03 00:41:26.474059'),('synyef6g03kc9liou9qj5muqeb8ay3d3','e30:1wJDYq:J_GnPE2vlf3Ld0gDXfUl0SnRxqpqy481M2usI21bgN8','2026-05-03 00:51:24.779178'),('t5kfhkp2agbjhjke91vqu8tuqfnit6gn','.eJxVjMsKwyAQAP_FcxGz8YE99t5vENdda9qiEJNT6L8XIYf2OjPMIULctxL2zmtYSFzFJC6_DGN6cR2CnrE-mkytbuuCciTytF3eG_H7drZ_gxJ7GVvjUbukENlZpOxn7ygiaD1DskppysZmhUCcTGREAFYO0wTeZmdBfL70fThT:1wJDLc:lvX39PetasNvcfzvcBswh_-UkKz1_eEVSdLbvpE1qj0','2026-05-03 00:37:44.211595'),('tu031zmh6riwngck4aoafk7jo9k8zg8n','.eJxVjEEOwiAQRe_C2pCAdAZcuvcMZGCmUjWQlHbVeHdt0oVu_3vvbyrSupS4dpnjxOqijDr9bonyU-oO-EH13nRudZmnpHdFH7TrW2N5XQ_376BQL98aLTL5s4B3AZxD8QQCbHHwCRIJUHJOYBzQZQiGbUBAYzOPwWdGUe8P1Xw31w:1wJZAi:mbuMXUVI5piYfaVhzlhcTldW1O0SHfRo_K34do2WHQM','2026-05-03 23:55:56.875120'),('u6zoso98iw8ru1k8ek19x7odk53tfgp8','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIn0:1wIqmF:ZGv1fyfR9jBBtAa5ukJjatW1F6JpZ50zLib3bbziATY','2026-05-02 00:31:43.835788'),('ug6gyxjgt304lfp005b1xq954gb1nrss','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJY5r:Ah-kEgwEEnJLtwYMWzqR6r_t5J4mQ_ojq2j65rzexEk','2026-05-03 22:46:51.792266'),('uvamijdvtboh6xqlky617ibc41lnwzoq','.eJxVjsEOwiAQRP-FsyEU6hY8eu83kF2W2qqBBOjJ-O-2pge9zpt5mZfwuLbZrzUWv7C4iE6cfjPC8IhpB3zHdMsy5NTKQnKvyINWOWaOz-vR_RPMWOdtbdCRmQAmBgcAfbCkFNE5IE_QRyZSZAaKdueMSiunabDWWeg0UNykrWCqGNqS0_cqwPsDqnw_KQ:1wPzba:RmW1aP0Dr9NFyUwq-MXNzrAPE3qoTw8kblFqeJ90BY0','2026-05-21 17:22:14.320348'),('v3dr9mg1jvao22yg26v423xrf5bk7xpb','.eJxVjsEOwiAQRP-FsyG0tFvw6N1vaHZZkKqBBOjJ-O-2pge9zpt5mZeYcW1xXqsv88LiLDpx-s0I3cOnHfAd0y1Ll1MrC8m9Ig9a5TWzf16O7p8gYo3bWqMlHQACgwWAwRlSimh0yAEGz0SK9ETe7JxR9cr2NBljDXQ9kN-krWCq6NqS0_eqHt8fqnE_JQ:1wLcTB:16690oYXGEz6CzNfyj70YiDzvD92ZdgpqzdeSSKmvNE','2026-05-09 15:51:29.158161'),('vmrv74o0w7h2pffxyf1r0cpcgpmou7rg','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJDCp:WoqbVwGR_qyhH47FZ5bOSVihHLsqmH8O4EPFIeX0HiU','2026-05-03 00:28:39.486549'),('wfr3t4hn19ihq8ikpf2ro5m1nbrgc239','.eJxVjsEOwiAQRP-FsyGU4hY8eu83kF2WWtRAUujJ-O-2pge9zpt5mZfwuLbZrzUuPrG4iE6cfjPC8Ih5B3zHfCsylNyWRHKvyINWORaOz-vR_RPMWOdt3aOjfgKYGBwAmGBJKaJzQJ7ARCZS1A8U7c4ZlVZO02Cts9BpoLhJ24K5Ymip5O9V494fqnw_Kg:1wN3oE:GhYJewLb2YLT78ThQJSCPfWnvVx0yrDLzPn9d1X8XgY','2026-05-13 15:15:10.501919'),('wkzfs7pvyla3nxs1gnde3owv833hagsi','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJYUZ:dkAYzgiVikkEt4MoBomIF-HVgPtEuJMQfHMdR8tPJfg','2026-05-03 23:12:23.614604'),('xxb42lizo0okjjukupo56gqlheyn4xtv','.eJxVjEEOwiAQAP_C2RB2i1A8evcNBNhFqgaS0p6MfzckPeh1ZjJv4cO-Fb93Xv1C4iJmcfplMaQn1yHoEeq9ydTqti5RjkQetstbI35dj_ZvUEIvYwsMkKM9O5OQaMKsAkZGBSZqwy4b0sgzOJWV1tEAYrbEEytiZa0Wny_gCzed:1wM34d:sad6qO9hEDqr-DNOWWJb3lHBA7BbBoO4NS1_2oQ5r5g','2026-05-10 20:15:55.566555'),('ybm1h0is80tssg69vhiuk9ryn879tsx1','.eJxVjEEOwiAQRe_C2hCgQBiX7j0DmWEGqZo2Ke3KeHdt0oVu_3vvv1TGbW1567LkkdVZWXX63QjLQ6Yd8B2n26zLPK3LSHpX9EG7vs4sz8vh_h007O1bCzgQEwZHlinE6k0lLzzYBIYFC1AsIM6AhyphiIm4-gSA3iFUU9T7A-4OOEk:1wIqkE:BbsnY-qZs75RumOsIzDl0ZkjkHF3-jCo2gNJjkd6gV4','2026-05-02 00:29:38.271391'),('z76u7g34kvxr1nghgqhl2k3g63aeqlnn','.eJxVjEEOwiAQRe_C2hAKdQou3fcMZIYBqRpISrsy3l1JutDtf-_9l_C4b9nvLa5-YXERgzj9boThEUsHfMdyqzLUsq0Lya7IgzY5V47P6-H-HWRs-VsbdGQSQGJwADAGS0oRnQNygjEykSIzUbSdMyqtnKbJWmdh0EBRvD_8pDhB:1wLH8u:1uUunl4ePMW80K-otra9hlG0rTH8yJ2_2fkvbU7E-ZY','2026-05-08 17:05:08.795322'),('zn06c0ab1byyux6eclslr4b7f5806e2h','eyJyZXNldF91c2VybmFtZSI6IkpCU09OIiwia2V5X3ZlcmlmaWVkIjpmYWxzZX0:1wJYZs:NjlXwA0n7vu2LVbYKFkaFo7gXiF_coTggBGyGfImrGw','2026-05-03 23:17:52.735659');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` varchar(20) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `description` longtext NOT NULL,
  `barcode_id` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int unsigned NOT NULL,
  `abc_classification` varchar(1) NOT NULL,
  `date_added` datetime(6) NOT NULL,
  `date_updated` datetime(6) NOT NULL,
  `category_id` bigint NOT NULL,
  `supplier_id` bigint DEFAULT NULL,
  `annual_demand` int unsigned NOT NULL,
  `reorder_point` int unsigned NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `actual_sales_count` int unsigned NOT NULL,
  `manual_annual_demand` int unsigned NOT NULL,
  `average_daily_sales` decimal(10,2) NOT NULL,
  `average_lead_time_days` int unsigned NOT NULL,
  `max_daily_sales` decimal(10,2) NOT NULL,
  `max_lead_time_days` int unsigned NOT NULL,
  `safety_stock` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  UNIQUE KEY `barcode_id` (`barcode_id`),
  KEY `inventory_category_id_c324f5a2_fk_categories_id` (`category_id`),
  KEY `inventory_supplier_id_a153dd16_fk_suppliers_id` (`supplier_id`),
  CONSTRAINT `inventory_category_id_c324f5a2_fk_categories_id` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `inventory_supplier_id_a153dd16_fk_suppliers_id` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `inventory_chk_1` CHECK ((`quantity` >= 0)),
  CONSTRAINT `inventory_chk_3` CHECK ((`annual_demand` >= 0)),
  CONSTRAINT `inventory_chk_4` CHECK ((`reorder_point` >= 0)),
  CONSTRAINT `inventory_chk_5` CHECK ((`actual_sales_count` >= 0)),
  CONSTRAINT `inventory_chk_6` CHECK ((`manual_annual_demand` >= 0)),
  CONSTRAINT `inventory_chk_7` CHECK ((`average_lead_time_days` >= 0)),
  CONSTRAINT `inventory_chk_8` CHECK ((`max_lead_time_days` >= 0)),
  CONSTRAINT `inventory_chk_9` CHECK ((`safety_stock` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (5,' MT001',' WD-40 Multi-Use 412g    ','','4803000400050',320.00,85,'A','2026-05-07 14:01:01.732233','2026-05-15 10:50:41.091449',7,4,1200,10,250.00,0,0,0.00,0,0.00,0,0),(7,'HAT001',' Stanley Tape Measure 5m  ','','4805000600070',250.00,9909,'A','2026-05-07 14:02:29.304871','2026-05-15 10:50:41.101511',8,6,800,10,180.00,0,0,0.00,0,0.00,0,0),(8,'HW001',' Common Wire Nails 2\" (1kg)  ','','4806000700080',85.00,124,'A','2026-05-07 14:03:18.617448','2026-05-15 10:50:41.122484',9,7,1500,10,60.00,0,0,0.00,0,0.00,0,0),(10,'EL001',' Omni LED Bulb 9W Daylight  ','','4808000900100',100.00,76,'B','2026-05-07 14:04:42.511794','2026-05-15 10:50:41.137988',11,9,800,10,75.00,0,0,0.00,0,0.00,0,0),(11,'CO002',' Green Cross Alcohol','','4800047826610',150.00,152,'C','2026-05-08 04:03:08.020736','2026-05-15 10:50:41.212975',5,1,0,10,67.00,0,0,0.00,0,0.00,0,0),(13,' MT002',' Pioneer Epoxy Clay Aqua','','4801111222333',180.00,119,'C','2026-05-09 08:01:54.146354','2026-05-15 10:50:41.196994',7,11,120,10,135.00,0,0,0.00,0,0.00,0,0),(14,' MT003',' Boysen Paint Thinner 1L','','4802222333444',125.00,56,'C','2026-05-09 08:02:39.113009','2026-05-15 10:50:41.154732',7,5,300,10,90.00,0,0,0.00,0,0.00,0,0),(15,' MT004',' 3M Scotch-Brite Heavy Duty','','4803333444555',45.00,147,'C','2026-05-09 08:03:20.177835','2026-05-15 10:50:41.167362',7,13,850,10,28.00,0,0,0.00,0,0.00,0,0),(16,' MT005',' Mighty Bond Instant Glue 3g','','4804444555666',65.00,80,'C','2026-05-09 08:04:18.106042','2026-05-15 10:50:41.171586',7,14,450,10,48.00,0,0,0.00,0,0.00,0,0),(17,' MT006',' Bostik No More Nails 320g ','','4805555666777',295.00,20,'C','2026-05-09 08:05:18.154907','2026-05-23 14:55:35.576095',7,15,85,0,210.00,0,0,0.00,0,0.00,0,0),(18,' MT007',' Tox with Screws Set 6mm (100s) ','','4806666777888',55.00,265,'B','2026-05-09 08:07:38.071610','2026-05-15 10:50:41.146379',9,16,1200,10,35.00,0,0,0.00,0,0.00,0,0),(21,'HAT002',' Alcohol','','4806520413889',100.00,18,'A','2026-05-15 03:25:49.566070','2026-05-23 14:55:40.690531',8,1,1000,0,90.00,0,0,0.00,0,0.00,0,0),(22,'HW008',' C2','','4800016052040',25.00,89,'B','2026-05-15 10:39:35.688625','2026-05-15 10:50:41.131087',9,7,3000,10,20.00,0,0,0.00,0,0.00,0,0);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_payments`
--

DROP TABLE IF EXISTS `invoice_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `amount` decimal(12,2) NOT NULL,
  `method` varchar(20) NOT NULL,
  `date` datetime(6) NOT NULL,
  `invoice_id` bigint NOT NULL,
  `processed_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_payments_invoice_id_07bf0f10_fk_invoices_id` (`invoice_id`),
  KEY `invoice_payments_processed_by_id_b95b8ca9_fk_security_user_id` (`processed_by_id`),
  CONSTRAINT `invoice_payments_invoice_id_07bf0f10_fk_invoices_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`),
  CONSTRAINT `invoice_payments_processed_by_id_b95b8ca9_fk_security_user_id` FOREIGN KEY (`processed_by_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_payments`
--

LOCK TABLES `invoice_payments` WRITE;
/*!40000 ALTER TABLE `invoice_payments` DISABLE KEYS */;
INSERT INTO `invoice_payments` VALUES (1,5575.00,'cash','2026-05-09 07:50:20.861506',1,1),(2,5000.00,'cash','2026-05-09 07:50:25.527085',1,1),(3,125.00,'cash','2026-05-15 03:32:56.014946',11,1),(4,100.00,'cash','2026-05-21 09:23:09.100469',18,1);
/*!40000 ALTER TABLE `invoice_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(20) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `balance_due` decimal(12,2) NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(10) NOT NULL,
  `customer_id` bigint DEFAULT NULL,
  `transaction_id` bigint DEFAULT NULL,
  `source` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_no` (`invoice_no`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `invoices_customer_id_de4a11fb_fk_customers_id` (`customer_id`),
  CONSTRAINT `invoices_customer_id_de4a11fb_fk_customers_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `invoices_transaction_id_11c231d8_fk_pos_transactions_id` FOREIGN KEY (`transaction_id`) REFERENCES `pos_transactions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,'INV-202605-DC316',10575.00,0.00,'2026-05-09','2026-06-08','paid',1,31,'manual'),(2,'INV-202605-611CD',505.00,0.00,'2026-05-11',NULL,'paid',NULL,41,'manual'),(4,'INV-202605-844BD',2445.00,0.00,'2026-05-11',NULL,'paid',NULL,42,'manual'),(5,'INV-202605-274E2',855.00,0.00,'2026-05-11',NULL,'paid',NULL,43,'manual'),(6,'INV-202605-F21E9',6660.00,0.00,'2026-05-12',NULL,'paid',NULL,45,'manual'),(7,'INV-202605-EC5A7',180.00,0.00,'2026-05-12',NULL,'paid',NULL,46,'manual'),(8,'INV-202605-9828B',90.00,0.00,'2026-05-12',NULL,'paid',NULL,47,'manual'),(9,'INV-202605-9C814',3240.00,0.00,'2026-05-15',NULL,'paid',NULL,50,'manual'),(10,'INV-202605-1E1F2',500.00,0.00,'2026-05-15',NULL,'paid',NULL,52,'manual'),(11,'INV-202605-09FB7',125.00,0.00,'2026-05-15','2026-06-14','paid',1,54,'manual'),(12,'INV-202605-5481F',14400.00,0.00,'2026-05-15',NULL,'paid',NULL,55,'manual'),(13,'INV-202605-27527',4425.00,0.00,'2026-05-15',NULL,'paid',NULL,57,'manual'),(14,'INV-202605-E8A3A',720.00,0.00,'2026-05-15',NULL,'paid',NULL,58,'manual'),(15,'INV-202605-7F7E4',1620.00,0.00,'2026-05-15',NULL,'paid',NULL,59,'manual'),(16,'INV-202605-BB9F6',1475.00,1475.00,'2026-05-15','2026-06-14','unpaid',1,62,'manual'),(17,'INV-202605-2B074',11375.00,0.00,'2026-05-15',NULL,'paid',NULL,63,'manual'),(18,'INV-202605-89BA2',200.00,100.00,'2026-05-21','2026-06-20','unpaid',1,65,'manual');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manual_articles`
--

DROP TABLE IF EXISTS `manual_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manual_articles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `order` smallint unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_created` datetime(6) NOT NULL,
  `date_updated` datetime(6) NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `section_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `manual_articles_created_by_id_8c80aa18_fk_users_id` (`created_by_id`),
  KEY `manual_articles_section_id_9a5f16f2_fk_manual_sections_id` (`section_id`),
  CONSTRAINT `manual_articles_created_by_id_8c80aa18_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `security_user` (`id`),
  CONSTRAINT `manual_articles_section_id_9a5f16f2_fk_manual_sections_id` FOREIGN KEY (`section_id`) REFERENCES `manual_sections` (`id`),
  CONSTRAINT `manual_articles_chk_1` CHECK ((`order` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_articles`
--

LOCK TABLES `manual_articles` WRITE;
/*!40000 ALTER TABLE `manual_articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `manual_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manual_sections`
--

DROP TABLE IF EXISTS `manual_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manual_sections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `section_type` varchar(20) NOT NULL,
  `order` smallint unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_updated` datetime(6) NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `manual_sections_created_by_id_0e24a1dd_fk_users_id` (`created_by_id`),
  CONSTRAINT `manual_sections_created_by_id_0e24a1dd_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `security_user` (`id`),
  CONSTRAINT `manual_sections_chk_1` CHECK ((`order` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_sections`
--

LOCK TABLES `manual_sections` WRITE;
/*!40000 ALTER TABLE `manual_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `manual_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `notification_type` varchar(20) NOT NULL,
  `priority` varchar(10) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` longtext NOT NULL,
  `source_table` varchar(50) NOT NULL,
  `source_id` varchar(50) NOT NULL,
  `is_read` tinyint(1) NOT NULL,
  `date_created` datetime(6) NOT NULL,
  `date_read` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `action_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notificatio_user_id_a4dd5c_idx` (`user_id`,`is_read`),
  KEY `notificatio_notific_19df93_idx` (`notification_type`),
  CONSTRAINT `notifications_user_id_468e288d_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,'low_stock','critical','Low Stock:  Pioneer Epoxy Clay Aqua','Stock dropped to 4 after a POS transaction. Please reorder.','inventory','13',1,'2026-05-12 02:37:44.038451','2026-05-12 02:37:46.944546',NULL,NULL),(2,'low_stock','critical','Low Stock:  Pioneer Epoxy Clay Aqua','Stock dropped to 3 after a POS transaction. Please reorder.','inventory','13',1,'2026-05-12 02:38:42.866283','2026-05-12 02:38:45.250494',NULL,NULL),(3,'low_stock','critical','Low Stock:  Pioneer Epoxy Clay Aqua','Stock dropped to 2 after a POS transaction. Please reorder.','inventory','13',1,'2026-05-15 03:18:16.265416','2026-05-15 03:19:14.110037',NULL,'/inventory/purchase-orders/create/?auto=true'),(4,'po_alert','medium','Delivery Expected Today','PO PO-CCD6F2 from Yatai Int\'l is scheduled to arrive today.','','po_today_6',1,'2026-05-15 03:19:34.622942','2026-05-15 03:19:50.622393',1,'/inventory/purchase-orders/create/'),(5,'password_reset','high','Password Reset Request','Employee \'JBSON\' requested a password reset. Review pending requests.','','',1,'2026-05-15 09:25:18.895379','2026-05-15 10:15:38.248294',1,'/auth/admin/review-resets/'),(6,'password_reset','high','Password Reset Request','Employee \'JBSON\' requested a password reset. Review pending requests.','','',1,'2026-05-15 10:16:00.810421','2026-05-15 10:20:25.785589',1,'/auth/admin/review-resets/'),(7,'password_reset','high','Password Reset Request','Employee \'test4\' requested a password reset. Review pending requests.','','',1,'2026-05-15 10:19:43.862598','2026-05-15 10:20:25.785589',1,'/auth/admin/review-resets/'),(8,'password_reset','high','Password Reset Request','Employee \'test4\' requested a password reset. Review pending requests.','','',1,'2026-05-15 10:45:30.123215','2026-05-15 10:52:39.632286',1,'/auth/admin/review-resets/'),(9,'low_stock','critical','Low Stock:  Bostik No More Nails 320g ','Stock dropped to 5 after a POS transaction. Please reorder.','inventory','17',1,'2026-05-15 10:47:15.787035','2026-05-15 10:52:39.632286',NULL,'/inventory/purchase-orders/create/?auto=true'),(10,'low_stock','critical','Low Stock:  Pioneer Epoxy Clay Aqua','Stock dropped to 9 after a POS transaction. Please reorder.','inventory','13',1,'2026-05-15 10:48:31.848765','2026-05-15 10:52:39.632286',NULL,'/inventory/purchase-orders/create/?auto=true'),(11,'po_alert','medium','Delivery Expected Today','PO PO-DA3534 from Pioneer Adhesives Inc. is scheduled to arrive today.','','po_today_7',1,'2026-05-15 10:49:58.538448','2026-05-15 10:52:39.632286',1,'/inventory/purchase-orders/create/'),(12,'po_alert','medium','Delivery Expected Today','PO PO-E22C42 from Bostik Philippines is scheduled to arrive today.','','po_today_8',1,'2026-05-15 10:50:14.944721','2026-05-15 10:52:39.632286',1,'/inventory/purchase-orders/create/'),(13,'low_stock','critical','Low Stock:  Bostik No More Nails 320g ','Stock dropped to 5 after a POS transaction. Please reorder.','inventory','17',1,'2026-05-15 11:04:45.820316','2026-05-15 11:14:19.329865',NULL,'/inventory/purchase-orders/create/?auto=true'),(14,'low_stock','critical','Low Stock:  Alcohol','Stock dropped to 5 after a POS transaction. Please reorder.','inventory','21',1,'2026-05-15 11:04:45.839900','2026-05-15 11:14:19.329865',NULL,'/inventory/purchase-orders/create/?auto=true'),(15,'po_alert','medium','Delivery Expected Today','PO PO-720273 from Bostik Philippines is scheduled to arrive today.','','po_today_9',1,'2026-05-15 11:06:13.238210','2026-05-15 11:14:19.329865',1,'/inventory/purchase-orders/create/'),(16,'po_alert','high','Overdue Delivery Alert','PO PO-720273 from Bostik Philippines was due on May 15. Please mark as received if it arrived.','','po_overdue_9',0,'2026-05-21 09:11:39.871665',NULL,1,'/inventory/purchase-orders/create/'),(17,'low_stock','critical','Low Stock:  Alcohol','Stock dropped to 3 after a POS transaction. Please reorder.','inventory','21',0,'2026-05-21 09:22:10.765277',NULL,NULL,'/inventory/purchase-orders/create/?auto=true'),(18,'po_alert','high','Overdue Delivery Alert','PO PO-BA380B from ABC was due on May 22. Please mark as received if it arrived.','','po_overdue_10',0,'2026-05-23 13:37:09.615362',NULL,1,'/inventory/purchase-orders/create/');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `payment_method` varchar(10) NOT NULL,
  `amount_due` decimal(12,2) NOT NULL,
  `amount_tendered` decimal(12,2) NOT NULL,
  `change_amount` decimal(12,2) NOT NULL,
  `status` varchar(10) NOT NULL,
  `reference_number` varchar(50) NOT NULL,
  `date_created` datetime(6) NOT NULL,
  `processed_by_id` bigint DEFAULT NULL,
  `transaction_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `payments_processed_by_id_f63d9d82_fk_users_id` (`processed_by_id`),
  CONSTRAINT `payments_processed_by_id_f63d9d82_fk_users_id` FOREIGN KEY (`processed_by_id`) REFERENCES `security_user` (`id`),
  CONSTRAINT `payments_transaction_id_4d63d462_fk_pos_transactions_id` FOREIGN KEY (`transaction_id`) REFERENCES `pos_transactions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,'cash',1250.00,2000.00,750.00,'success','','2026-05-08 14:44:06.906348',NULL,12),(2,'cash',16750.00,17000.00,250.00,'success','','2026-05-09 03:19:45.453489',NULL,14),(3,'cash',1000.00,1000.00,0.00,'success','','2026-05-09 03:56:36.730997',NULL,16),(4,'cash',1630.00,2000.00,370.00,'success','','2026-05-10 08:30:14.770142',NULL,37),(5,'bank',1295.00,1295.00,0.00,'success','','2026-05-10 10:46:24.555670',NULL,38),(6,'cash',505.00,505.00,0.00,'success','','2026-05-11 08:49:05.849399',NULL,41),(8,'cash',2445.00,2500.00,55.00,'success','','2026-05-11 09:32:52.612517',NULL,42),(9,'cash',855.00,900.00,45.00,'success','','2026-05-11 10:04:22.231957',NULL,43),(10,'cash',6660.00,7000.00,340.00,'success','','2026-05-12 02:37:44.043038',NULL,45),(11,'cash',180.00,200.00,20.00,'success','','2026-05-12 02:38:42.870323',NULL,46),(12,'cash',90.00,100.00,10.00,'success','','2026-05-12 05:18:17.233672',NULL,47),(13,'cash',3240.00,4000.00,760.00,'success','','2026-05-15 03:18:16.265416',NULL,50),(14,'bank',500.00,500.00,0.00,'success','','2026-05-15 03:30:37.649891',NULL,52),(15,'cash',14400.00,15000.00,600.00,'success','','2026-05-15 08:46:31.718417',NULL,55),(16,'cash',4425.00,5000.00,575.00,'success','','2026-05-15 10:47:15.796605',NULL,57),(17,'cash',720.00,1000.00,280.00,'success','','2026-05-15 10:48:02.292792',NULL,58),(18,'cash',1620.00,2000.00,380.00,'success','','2026-05-15 10:48:31.852990',NULL,59),(19,'cash',11375.00,12000.00,625.00,'success','','2026-05-15 11:04:45.844747',NULL,63);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_transaction_items`
--

DROP TABLE IF EXISTS `pos_transaction_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_transaction_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` int unsigned NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `inventory_item_id` bigint NOT NULL,
  `transaction_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pos_transaction_items_inventory_item_id_90a311f8_fk_inventory_id` (`inventory_item_id`),
  KEY `pos_transaction_item_transaction_id_d746f8ae_fk_pos_trans` (`transaction_id`),
  CONSTRAINT `pos_transaction_item_transaction_id_d746f8ae_fk_pos_trans` FOREIGN KEY (`transaction_id`) REFERENCES `pos_transactions` (`id`),
  CONSTRAINT `pos_transaction_items_inventory_item_id_90a311f8_fk_inventory_id` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory` (`id`),
  CONSTRAINT `pos_transaction_items_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_transaction_items`
--

LOCK TABLES `pos_transaction_items` WRITE;
/*!40000 ALTER TABLE `pos_transaction_items` DISABLE KEYS */;
INSERT INTO `pos_transaction_items` VALUES (1,2,150.00,300.00,11,1),(2,1,250.00,250.00,7,1),(3,1,320.00,320.00,5,1),(4,1,320.00,320.00,5,3),(5,1,150.00,150.00,11,3),(6,1,85.00,85.00,8,3),(7,1,250.00,250.00,7,4),(8,1,85.00,85.00,8,4),(9,10,85.00,850.00,8,5),(10,1,150.00,150.00,11,6),(11,5,85.00,425.00,8,6),(12,1,100.00,100.00,10,7),(13,6,100.00,600.00,10,8),(14,1,250.00,250.00,7,8),(15,1,150.00,150.00,11,8),(16,1,320.00,320.00,5,8),(17,1,85.00,85.00,8,8),(18,4,250.00,1000.00,7,16),(19,3,150.00,450.00,11,17),(20,3,85.00,255.00,8,18),(22,1,250.00,250.00,7,25),(23,2,250.00,500.00,7,26),(24,2,150.00,300.00,11,27),(25,1,150.00,150.00,11,28),(26,1,250.00,250.00,7,28),(27,1,100.00,100.00,10,28),(28,1,85.00,85.00,8,28),(29,12,250.00,3000.00,7,31),(30,10,100.00,1000.00,10,31),(31,9,85.00,765.00,8,31),(32,13,320.00,4160.00,5,31),(33,11,150.00,1650.00,11,31),(34,1,85.00,85.00,8,36),(35,3,295.00,885.00,17,37),(36,4,85.00,340.00,8,37),(37,1,125.00,125.00,14,37),(38,2,65.00,130.00,16,37),(39,1,150.00,150.00,11,37),(40,5,85.00,425.00,8,38),(41,1,295.00,295.00,17,38),(42,1,45.00,45.00,15,38),(43,2,125.00,250.00,14,38),(44,2,65.00,130.00,16,38),(45,1,150.00,150.00,11,38),(46,1,45.00,45.00,15,40),(47,1,295.00,295.00,17,40),(48,1,125.00,125.00,14,40),(49,1,100.00,100.00,10,40),(50,1,65.00,65.00,16,40),(51,1,150.00,150.00,11,40),(52,1,55.00,55.00,18,40),(53,1,320.00,320.00,5,40),(54,1,180.00,180.00,13,40),(55,1,85.00,85.00,8,40),(56,1,125.00,125.00,14,41),(57,1,85.00,85.00,8,41),(58,1,295.00,295.00,17,41),(59,1,85.00,85.00,8,42),(60,3,125.00,375.00,14,42),(61,3,295.00,885.00,17,42),(62,3,65.00,195.00,16,42),(63,2,100.00,200.00,10,42),(64,1,180.00,180.00,13,42),(65,1,55.00,55.00,18,42),(66,1,320.00,320.00,5,42),(67,1,150.00,150.00,11,42),(68,1,125.00,125.00,14,43),(69,1,295.00,295.00,17,43),(70,1,65.00,65.00,16,43),(71,2,100.00,200.00,10,43),(72,2,85.00,170.00,8,43),(73,37,180.00,6660.00,13,45),(74,1,180.00,180.00,13,46),(75,2,45.00,90.00,15,47),(78,18,180.00,3240.00,13,50),(80,5,100.00,500.00,21,52),(81,1,125.00,125.00,14,54),(82,80,180.00,14400.00,13,55),(85,15,295.00,4425.00,17,57),(86,4,180.00,720.00,13,58),(87,9,180.00,1620.00,13,59),(89,5,295.00,1475.00,17,62),(90,25,295.00,7375.00,17,63),(91,40,100.00,4000.00,21,63),(92,2,100.00,200.00,21,65);
/*!40000 ALTER TABLE `pos_transaction_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_transactions`
--

DROP TABLE IF EXISTS `pos_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_transactions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `transaction_ref` varchar(20) NOT NULL,
  `status` varchar(15) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `void_reason` longtext NOT NULL,
  `date_created` datetime(6) NOT NULL,
  `date_completed` datetime(6) DEFAULT NULL,
  `processed_by_id` bigint DEFAULT NULL,
  `payment_method` varchar(20) NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_ref` (`transaction_ref`),
  KEY `pos_transactions_processed_by_id_d32c7ca5_fk_users_id` (`processed_by_id`),
  KEY `pos_transac_transac_453d3e_idx` (`transaction_ref`),
  KEY `pos_transactions_customer_id_3f6ab383_fk_customers_id` (`customer_id`),
  CONSTRAINT `pos_transactions_customer_id_3f6ab383_fk_customers_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `pos_transactions_processed_by_id_d32c7ca5_fk_users_id` FOREIGN KEY (`processed_by_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_transactions`
--

LOCK TABLES `pos_transactions` WRITE;
/*!40000 ALTER TABLE `pos_transactions` DISABLE KEYS */;
INSERT INTO `pos_transactions` VALUES (1,'TXN-20260508-DFA9AC','voided',870.00,870.00,'','2026-05-08 04:04:03.549063',NULL,1,'Cash',NULL,NULL),(2,'TXN-20260508-6C435D','voided',0.00,0.00,'','2026-05-08 04:04:29.664349',NULL,1,'Cash',NULL,NULL),(3,'TXN-20260508-2E2CC4','voided',555.00,555.00,'','2026-05-08 04:04:32.218205',NULL,1,'Cash',NULL,NULL),(4,'TXN-20260508-0E9CA5','completed',335.00,335.00,'','2026-05-08 07:07:07.181844',NULL,1,'Cash',NULL,NULL),(5,'TXN-20260508-13DD02','completed',850.00,850.00,'','2026-05-08 07:07:23.949256',NULL,1,'Cash',NULL,NULL),(6,'TXN-20260508-3E9CDD','voided',575.00,575.00,'','2026-05-08 07:08:19.335620',NULL,1,'Cash',NULL,NULL),(7,'TXN-20260508-A4887B','voided',100.00,100.00,'','2026-05-08 07:10:36.272500',NULL,1,'Cash',NULL,NULL),(8,'TXN-20260508-BE80CD','voided',1405.00,1405.00,'','2026-05-08 07:12:15.587095',NULL,1,'Cash',NULL,NULL),(9,'TXN-20260508-2D5B3D','voided',1135.00,1135.00,'','2026-05-08 11:43:34.560121',NULL,1,'Cash',NULL,NULL),(10,'TXN-20260508-C4D3FF','completed',840.00,840.00,'','2026-05-08 11:43:56.359517','2026-05-08 12:13:03.283443',1,'Cash','',NULL),(11,'TXN-20260508-DF1EB3','voided',600.00,600.00,'','2026-05-08 12:13:08.328947',NULL,1,'Cash',NULL,NULL),(12,'TXN-20260508-05EB5E','completed',1250.00,1250.00,'','2026-05-08 14:09:27.925301','2026-05-08 14:44:06.904165',1,'cash','',NULL),(13,'TXN-20260508-1A1E37','voided',0.00,0.00,'','2026-05-08 14:44:15.060947',NULL,1,'Cash',NULL,NULL),(14,'TXN-20260509-E07B68','completed',250.00,16750.00,'','2026-05-09 02:40:20.409604','2026-05-09 03:19:45.451228',1,'cash','',NULL),(15,'TXN-20260509-992C66','voided',0.00,0.00,'','2026-05-09 03:19:49.332616',NULL,1,'Cash',NULL,NULL),(16,'TXN-20260509-7BC097','completed',1000.00,1000.00,'','2026-05-09 03:26:45.509029','2026-05-09 03:56:36.730008',1,'cash','',NULL),(17,'TXN-20260509-9B71B5','voided',450.00,450.00,'','2026-05-09 03:56:40.065441',NULL,1,'Cash',NULL,NULL),(18,'TXN-20260509-335595','voided',255.00,255.00,'','2026-05-09 04:27:26.785081',NULL,1,'Cash',NULL,NULL),(19,'TXN-20260509-2CB25E','voided',0.00,0.00,'','2026-05-09 04:37:08.153189',NULL,1,'Cash',NULL,NULL),(20,'TXN-20260509-5FF623','voided',0.00,0.00,'','2026-05-09 04:51:35.073603',NULL,1,'Cash',NULL,NULL),(21,'TXN-20260509-EF3304','voided',0.00,0.00,'','2026-05-09 04:52:47.413215',NULL,1,'Cash',NULL,NULL),(22,'TXN-20260509-302851','voided',0.00,0.00,'','2026-05-09 04:53:47.851054',NULL,1,'Cash',NULL,NULL),(23,'TXN-20260509-BB4D8A','voided',200.00,0.00,'','2026-05-09 04:55:01.889228',NULL,1,'Cash',NULL,NULL),(24,'TXN-20260509-177ACA','voided',0.00,0.00,'','2026-05-09 04:55:17.388166',NULL,1,'Cash',NULL,NULL),(25,'TXN-20260509-AD79A8','voided',250.00,250.00,'','2026-05-09 04:55:19.713763',NULL,1,'Cash',NULL,NULL),(26,'TXN-20260509-492159','voided',500.00,500.00,'','2026-05-09 04:55:22.228867',NULL,1,'Cash',NULL,NULL),(27,'TXN-20260509-D25B0A','voided',300.00,300.00,'','2026-05-09 04:56:37.118759',NULL,1,'Cash',NULL,NULL),(28,'TXN-20260509-92CF6A','voided',585.00,585.00,'','2026-05-09 05:02:33.946101',NULL,1,'Cash',NULL,NULL),(29,'TXN-20260509-A45D6C','voided',0.00,0.00,'','2026-05-09 05:09:56.277065',NULL,1,'Cash',NULL,NULL),(30,'TXN-20260509-A412E6','voided',0.00,0.00,'','2026-05-09 05:16:35.175460',NULL,1,'Cash',NULL,NULL),(31,'TXN-20260509-0605EA','credit',10575.00,10575.00,'','2026-05-09 07:49:24.989409','2026-05-09 07:50:00.927105',1,'credit',NULL,1),(32,'TXN-20260509-AC68FF','voided',0.00,0.00,'','2026-05-09 07:50:07.044627',NULL,1,'Cash',NULL,NULL),(33,'TXN-20260509-13ECEB','voided',0.00,0.00,'','2026-05-09 07:51:12.324727',NULL,1,'Cash',NULL,NULL),(34,'TXN-20260509-E156FF','voided',0.00,0.00,'','2026-05-09 07:51:23.679886',NULL,1,'Cash',NULL,NULL),(35,'TXN-20260509-2A3AC5','voided',0.00,0.00,'','2026-05-09 07:51:29.127344',NULL,1,'Cash',NULL,NULL),(36,'TXN-20260510-DB9902','quotation',85.00,85.00,'','2026-05-10 08:12:55.154778',NULL,1,'Cash',NULL,NULL),(37,'TXN-20260510-C96B6F','completed',1630.00,1630.00,'','2026-05-10 08:13:11.125257','2026-05-10 08:30:14.768130',1,'cash','',NULL),(38,'TXN-20260510-92A088','completed',1295.00,1295.00,'','2026-05-10 08:31:55.763081','2026-05-10 10:46:24.552662',1,'bank','123123143242',NULL),(39,'TXN-20260510-3EB4AC','voided',0.00,0.00,'','2026-05-10 10:46:29.646618',NULL,1,'Cash',NULL,NULL),(40,'TXN-20260511-E3AA9E','voided',1420.00,1420.00,'','2026-05-11 07:24:43.557709',NULL,1,'Cash',NULL,NULL),(41,'TXN-20260511-8B3577','completed',505.00,505.00,'','2026-05-11 07:26:24.973687','2026-05-11 08:49:05.848395',1,'cash','',NULL),(42,'TXN-20260511-E269FC','completed',2445.00,2445.00,'','2026-05-11 08:49:08.869572','2026-05-11 09:32:52.609452',1,'cash','',NULL),(43,'TXN-20260511-CFA03A','completed',855.00,855.00,'','2026-05-11 09:32:55.068162','2026-05-11 10:04:22.230944',1,'cash','',NULL),(44,'TXN-20260511-9DA470','open',0.00,0.00,'','2026-05-11 10:04:44.287960',NULL,1,'Cash',NULL,NULL),(45,'TXN-20260512-9E0B46','completed',180.00,6660.00,'','2026-05-12 02:37:07.775796','2026-05-12 02:37:44.040982',1,'cash','',NULL),(46,'TXN-20260512-80650F','completed',180.00,180.00,'','2026-05-12 02:37:45.619408','2026-05-12 02:38:42.868287',1,'cash','',NULL),(47,'TXN-20260512-779BB4','completed',90.00,90.00,'','2026-05-12 02:38:44.152817','2026-05-12 05:18:17.231122',1,'cash','',NULL),(48,'TXN-20260512-CD58A8','open',0.00,0.00,'','2026-05-12 05:18:37.246453',NULL,1,'Cash',NULL,NULL),(49,'TXN-20260513-7C5BDA','open',0.00,0.00,'','2026-05-13 07:15:10.408475',NULL,1,'Cash',NULL,NULL),(50,'TXN-20260515-A28ADE','completed',180.00,3240.00,'','2026-05-15 03:13:06.831543','2026-05-15 03:18:16.265416',1,'cash','',NULL),(52,'TXN-20260515-1A6E79','completed',100.00,500.00,'','2026-05-15 03:26:36.264323','2026-05-15 03:30:37.648807',1,'bank','7647347324783847',NULL),(53,'TXN-20260515-A9AF60','open',0.00,0.00,'','2026-05-15 03:30:17.319142',NULL,1,'Cash',NULL,NULL),(54,'TXN-20260515-19189A','credit',125.00,125.00,'','2026-05-15 03:30:45.074593','2026-05-15 03:32:37.613321',1,'credit',NULL,1),(55,'TXN-20260515-29FEA9','completed',180.00,14400.00,'','2026-05-15 03:32:40.029374','2026-05-15 08:46:31.717077',1,'cash','',NULL),(56,'TXN-20260515-7D688B','open',0.00,0.00,'','2026-05-15 08:46:34.128236',NULL,1,'Cash',NULL,NULL),(57,'TXN-20260515-B6DFA8','completed',495.00,4425.00,'','2026-05-15 10:13:44.228805','2026-05-15 10:47:15.793962',1,'cash','',NULL),(58,'TXN-20260515-EEF89A','completed',180.00,720.00,'','2026-05-15 10:47:19.336201','2026-05-15 10:48:02.291770',1,'cash','',NULL),(59,'TXN-20260515-1D65F5','completed',180.00,1620.00,'','2026-05-15 10:48:03.706618','2026-05-15 10:48:31.850846',1,'cash','',NULL),(60,'TXN-20260515-11D9A7','open',0.00,0.00,'','2026-05-15 10:48:33.276267',NULL,1,'Cash',NULL,NULL),(61,'TXN-20260515-66CF99','open',0.00,0.00,'','2026-05-15 10:57:30.533563',NULL,1,'Cash',NULL,NULL),(62,'TXN-20260515-BF305C','credit',395.00,1475.00,'','2026-05-15 11:00:19.031834','2026-05-15 11:01:37.318444',1,'credit',NULL,1),(63,'TXN-20260515-5F71C2','completed',7475.00,11375.00,'','2026-05-15 11:01:40.184992','2026-05-15 11:04:45.841916',1,'cash','',NULL),(64,'TXN-20260515-2FC0B6','open',0.00,0.00,'','2026-05-15 11:04:48.070387',NULL,1,'Cash',NULL,NULL),(65,'TXN-20260521-D55DF0','credit',200.00,200.00,'','2026-05-21 09:20:05.494085','2026-05-21 09:22:10.774294',1,'credit',NULL,1),(66,'TXN-20260521-252C9F','open',0.00,0.00,'','2026-05-21 09:22:14.255805',NULL,1,'Cash',NULL,NULL),(67,'TXN-20260523-41EDA1','open',0.00,0.00,'','2026-05-23 14:55:01.633892',NULL,1,'Cash',NULL,NULL);
/*!40000 ALTER TABLE `pos_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_registration_logs`
--

DROP TABLE IF EXISTS `product_registration_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_registration_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` varchar(15) NOT NULL,
  `barcode_value` varchar(50) NOT NULL,
  `notes` longtext NOT NULL,
  `registered_at` datetime(6) NOT NULL,
  `inventory_item_id` bigint NOT NULL,
  `registered_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_registration_inventory_item_id_9b46dae0_fk_inventory` (`inventory_item_id`),
  KEY `product_registration_logs_registered_by_id_d8561a41_fk_users_id` (`registered_by_id`),
  CONSTRAINT `product_registration_inventory_item_id_9b46dae0_fk_inventory` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory` (`id`),
  CONSTRAINT `product_registration_logs_registered_by_id_d8561a41_fk_users_id` FOREIGN KEY (`registered_by_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_registration_logs`
--

LOCK TABLES `product_registration_logs` WRITE;
/*!40000 ALTER TABLE `product_registration_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_registration_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity_ordered` int unsigned NOT NULL,
  `quantity_received` int unsigned NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `product_id` bigint NOT NULL,
  `purchase_order_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_items_product_id_fbb97bae_fk_inventory_id` (`product_id`),
  KEY `purchase_order_items_purchase_order_id_0c2f986f_fk_purchase_` (`purchase_order_id`),
  CONSTRAINT `purchase_order_items_product_id_fbb97bae_fk_inventory_id` FOREIGN KEY (`product_id`) REFERENCES `inventory` (`id`),
  CONSTRAINT `purchase_order_items_purchase_order_id_0c2f986f_fk_purchase_` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`),
  CONSTRAINT `purchase_order_items_chk_1` CHECK ((`quantity_ordered` >= 0)),
  CONSTRAINT `purchase_order_items_chk_2` CHECK ((`quantity_received` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
INSERT INTO `purchase_order_items` VALUES (1,56,56,35.00,18,1),(2,67,67,67.00,11,2),(3,17,17,135.00,13,3),(5,13,13,210.00,17,4),(6,100,100,135.00,13,5),(7,2,2,75.00,10,6),(8,110,110,135.00,13,7),(9,30,30,210.00,17,8),(10,15,15,210.00,17,9),(11,15,15,90.00,21,10);
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `po_number` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `order_date` datetime(6) NOT NULL,
  `expected_delivery` date DEFAULT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `supplier_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_number` (`po_number`),
  KEY `purchase_orders_supplier_id_ea68c110_fk_suppliers_id` (`supplier_id`),
  CONSTRAINT `purchase_orders_supplier_id_ea68c110_fk_suppliers_id` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
INSERT INTO `purchase_orders` VALUES (1,'PO-C97D2C','received','2026-05-11 09:33:15.729192','2026-05-28',1960.00,1),(2,'PO-BC6513','received','2026-05-12 02:34:24.810936','2026-05-12',4489.00,1),(3,'PO-EE51C0','received','2026-05-12 06:54:53.888476','2026-05-19',2295.00,11),(4,'PO-88514E','received','2026-05-12 06:56:17.641942','2026-05-19',2730.00,15),(5,'PO-09D5DE','received','2026-05-15 03:19:09.674676','2026-05-22',13500.00,11),(6,'PO-CCD6F2','received','2026-05-15 03:19:33.606749','2026-05-15',150.00,9),(7,'PO-DA3534','received','2026-05-15 10:49:58.249196','2026-05-15',14850.00,11),(8,'PO-E22C42','received','2026-05-15 10:50:14.676653','2026-05-15',6300.00,15),(9,'PO-720273','received','2026-05-15 11:06:12.824910','2026-05-15',3150.00,15),(10,'PO-BA380B','received','2026-05-15 11:09:05.467001','2026-05-22',1350.00,1);
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `receipt_number` varchar(30) NOT NULL,
  `pdf_file` varchar(100) DEFAULT NULL,
  `date_issued` datetime(6) NOT NULL,
  `payment_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `receipt_number` (`receipt_number`),
  UNIQUE KEY `payment_id` (`payment_id`),
  CONSTRAINT `receipts_payment_id_d344b3f0_fk_payments_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `report_type` varchar(20) NOT NULL,
  `period` varchar(10) NOT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `file_path` varchar(100) DEFAULT NULL,
  `source_table` varchar(50) NOT NULL,
  `date_generated` datetime(6) NOT NULL,
  `generated_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_generated_by_id_18d9bf61_fk_users_id` (`generated_by_id`),
  CONSTRAINT `reports_generated_by_id_18d9bf61_fk_users_id` FOREIGN KEY (`generated_by_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports_analytics_expense`
--

DROP TABLE IF EXISTS `reports_analytics_expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports_analytics_expense` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `category` varchar(50) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `expense_date` date NOT NULL,
  `date_added` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports_analytics_expense`
--

LOCK TABLES `reports_analytics_expense` WRITE;
/*!40000 ALTER TABLE `reports_analytics_expense` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports_analytics_expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restore_records`
--

DROP TABLE IF EXISTS `restore_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restore_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `file_used` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  `error_message` longtext NOT NULL,
  `date_restored` datetime(6) NOT NULL,
  `backup_record_id` bigint DEFAULT NULL,
  `restored_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `restore_records_backup_record_id_f5022c7e_fk_backup_records_id` (`backup_record_id`),
  KEY `restore_records_restored_by_id_eab8c2b7_fk_users_id` (`restored_by_id`),
  CONSTRAINT `restore_records_backup_record_id_f5022c7e_fk_backup_records_id` FOREIGN KEY (`backup_record_id`) REFERENCES `backup_records` (`id`),
  CONSTRAINT `restore_records_restored_by_id_eab8c2b7_fk_users_id` FOREIGN KEY (`restored_by_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restore_records`
--

LOCK TABLES `restore_records` WRITE;
/*!40000 ALTER TABLE `restore_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `restore_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_logs`
--

DROP TABLE IF EXISTS `search_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `query_text` varchar(200) NOT NULL,
  `result_table` varchar(50) NOT NULL,
  `result_count` int unsigned NOT NULL,
  `date_searched` datetime(6) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `search_logs_user_id_a26c986c_fk_users_id` (`user_id`),
  KEY `search_logs_query_t_7ee78f_idx` (`query_text`),
  CONSTRAINT `search_logs_user_id_a26c986c_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `security_user` (`id`),
  CONSTRAINT `search_logs_chk_1` CHECK ((`result_count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_logs`
--

LOCK TABLES `search_logs` WRITE;
/*!40000 ALTER TABLE `search_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_activity_log`
--

DROP TABLE IF EXISTS `security_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_activity_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `timestamp` datetime(6) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `security_activity_log_user_id_e337638d_fk_security_user_id` (`user_id`),
  CONSTRAINT `security_activity_log_user_id_e337638d_fk_security_user_id` FOREIGN KEY (`user_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_activity_log`
--

LOCK TABLES `security_activity_log` WRITE;
/*!40000 ALTER TABLE `security_activity_log` DISABLE KEYS */;
INSERT INTO `security_activity_log` VALUES (1,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-01 16:31:43.817744',1),(2,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-02 13:57:02.419320',1),(3,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-02 14:55:21.662888',1),(4,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-02 15:11:38.801966',1),(5,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-02 16:21:03.523993',1),(6,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-02 16:27:07.383632',1),(7,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-02 16:28:39.475650',1),(8,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-02 16:31:27.651913',1),(9,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-02 16:33:14.507786',1),(10,'PASSWORD_CHANGED','User \'JBSON\' successfully reset their password via recovery key.','127.0.0.1','2026-05-02 16:37:32.669613',1),(11,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-02 16:37:44.204145',1),(12,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-02 16:40:00.211651',1),(13,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-02 16:40:14.546296',1),(14,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-02 16:40:40.066288',1),(15,'PASSWORD_CHANGED','User \'JBSON\' successfully reset their password via recovery key.','127.0.0.1','2026-05-02 16:41:15.932658',1),(16,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-02 16:41:26.468022',1),(17,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-02 16:50:46.805913',1),(18,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-02 16:50:56.694093',1),(19,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-02 16:51:06.445983',1),(20,'PASSWORD_CHANGED','User \'JBSON\' successfully reset their password via recovery key.','127.0.0.1','2026-05-02 16:51:24.773648',1),(21,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-03 14:17:27.069510',1),(22,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-03 14:23:19.270235',1),(23,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-03 14:30:01.477988',1),(24,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-03 14:33:07.506125',1),(25,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-03 14:33:21.461519',1),(26,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-03 14:36:06.179180',1),(27,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 14:36:42.092651',1),(28,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-03 14:40:20.560455',1),(29,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 14:41:03.439842',1),(30,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 14:43:03.672637',1),(31,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 14:43:40.356745',1),(32,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 14:46:51.784751',1),(33,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 14:52:39.202316',1),(34,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 14:54:00.146269',1),(35,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:04:56.958071',1),(36,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:12:23.607591',1),(37,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:12:35.059024',1),(38,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:17:52.729638',1),(39,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:18:04.786590',1),(40,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:20:22.942980',1),(41,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:20:33.881548',1),(42,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:28:15.415203',1),(43,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:28:21.544444',1),(44,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:29:53.470502',1),(45,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:30:18.089161',1),(46,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:42:37.119544',1),(47,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:42:51.285418',1),(48,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:45:40.993404',1),(49,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:45:48.198892',1),(50,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:47:53.279890',1),(51,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:48:24.012617',1),(52,'PASSWORD_CHANGED','User \'JBSON\' successfully reset their password via recovery key.','127.0.0.1','2026-05-03 15:54:39.201331',1),(53,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-03 15:54:47.319616',1),(54,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-03 15:55:56.871907',1),(55,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:56:22.873699',1),(56,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-03 15:56:47.950680',1),(57,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-03 15:57:01.285148',1),(58,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-07 13:25:19.985008',1),(59,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-08 03:18:35.467375',1),(60,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-08 08:41:23.677864',1),(61,'LOGIN','User \'wejelle\' logged in successfully.','127.0.0.1','2026-05-08 08:41:34.858444',NULL),(62,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-08 09:03:28.944543',1),(63,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-08 09:04:00.975230',1),(64,'LOGOUT','User \'wejelle\' logged out.','127.0.0.1','2026-05-08 09:04:26.983339',NULL),(65,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-08 09:04:28.980622',1),(66,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-08 09:04:35.897462',1),(67,'PASSWORD_CHANGED','User \'JBSON\' successfully reset their password via recovery key.','127.0.0.1','2026-05-08 09:05:05.291451',1),(68,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-08 09:05:08.791373',1),(69,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-08 09:34:54.977518',1),(70,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-09 02:38:58.673870',1),(71,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-09 03:20:35.604456',1),(72,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-09 03:22:34.494114',1),(73,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-09 03:23:43.344413',1),(74,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-09 03:23:46.899264',1),(75,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-09 03:23:52.453599',1),(76,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-09 03:26:41.067952',1),(77,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-09 07:48:50.495789',1),(78,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-10 08:12:33.655544',1),(79,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-10 12:14:27.302559',1),(80,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-10 12:15:00.473038',1),(81,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-10 12:15:45.326635',1),(82,'LOGIN','User \'jewelle\' logged in successfully.','127.0.0.1','2026-05-10 12:15:55.560377',8),(83,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-11 07:24:04.957572',1),(84,'GENERATE REPORT','Generated Sales Report (All Time)',NULL,'2026-05-11 09:32:26.154571',1),(85,'GENERATE REPORT','Generated Purchase Report (All Time)',NULL,'2026-05-11 09:32:28.207376',1),(86,'GENERATE REPORT','Generated Inventory Valuation Report (All Time)',NULL,'2026-05-11 09:32:29.021669',1),(87,'GENERATE REPORT','Generated Invoice Report (All Time)',NULL,'2026-05-11 09:32:30.063801',1),(88,'GENERATE REPORT','Generated Procurement Dashboard Report',NULL,'2026-05-11 09:32:31.247107',1),(89,'GENERATE REPORT','Generated Profit & Loss Report (All Time)',NULL,'2026-05-11 09:32:32.769515',1),(90,'POS TRANSACTION','Processed POS transaction TXN-20260511-E269FC via Cash (Total: ₱2445.00)',NULL,'2026-05-11 09:32:52.655749',1),(91,'CREATE PO','Created Purchase Order PO-C97D2C for supplier ABC (Total: ₱1960.00)',NULL,'2026-05-11 09:33:15.758962',1),(92,'RECEIVE PO','Received delivery for PO PO-C97D2C. Inventory stocks and costs updated.',NULL,'2026-05-11 09:33:42.029800',1),(93,'GENERATE REPORT','Generated Profit & Loss Report (All Time)',NULL,'2026-05-11 09:34:07.008012',1),(94,'GENERATE REPORT','Generated Sales Report (All Time)',NULL,'2026-05-11 09:34:11.445909',1),(95,'GENERATE REPORT','Generated Sales Report (All Time)',NULL,'2026-05-11 09:34:12.656136',1),(96,'GENERATE REPORT','Generated Procurement Dashboard Report',NULL,'2026-05-11 09:34:23.983299',1),(97,'GENERATE REPORT','Generated Purchase Report (All Time)',NULL,'2026-05-11 09:34:33.112599',1),(98,'GENERATE REPORT','Generated Sales Report from 2026-05-13 to 2026-05-13',NULL,'2026-05-11 09:43:31.118847',1),(99,'GENERATE REPORT','Generated Sales Report (All Time)',NULL,'2026-05-11 09:50:39.587534',1),(100,'GENERATE REPORT','Generated Procurement Dashboard Report',NULL,'2026-05-11 09:51:24.347741',1),(101,'GENERATE REPORT','Generated Procurement Dashboard Report',NULL,'2026-05-11 09:51:25.044998',1),(102,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-11 09:57:26.843341',1),(103,'POS TRANSACTION','Processed POS transaction TXN-20260511-CFA03A via Cash (Total: ₱855.00)',NULL,'2026-05-11 10:04:22.258961',1),(104,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-11 10:05:07.118883',1),(105,'GENERATE REPORT','Generated Sales Report from 2026-05-03 to 2026-05-11',NULL,'2026-05-11 10:06:12.598833',1),(106,'ARCHIVE SUPPLIER','Archived supplier \'3M Philippines\'',NULL,'2026-05-11 10:06:46.571766',1),(107,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-12 02:33:16.759445',1),(108,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-12 02:34:05.690761',1),(109,'CREATE PO','Created Purchase Order PO-BC6513 for supplier ABC (Total: ₱4489.00)',NULL,'2026-05-12 02:34:24.843381',1),(110,'RECEIVE PO','Received delivery for PO PO-BC6513. Inventory stocks and costs updated.',NULL,'2026-05-12 02:34:48.151381',1),(111,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-12 02:37:17.500204',1),(112,'POS TRANSACTION','Processed POS transaction TXN-20260512-9E0B46 via Cash (Total: ₱6660.00)',NULL,'2026-05-12 02:37:44.055077',1),(113,'POS TRANSACTION','Processed POS transaction TXN-20260512-80650F via Cash (Total: ₱180.00)',NULL,'2026-05-12 02:38:42.880421',1),(114,'POS TRANSACTION','Processed POS transaction TXN-20260512-779BB4 via Cash (Total: ₱90.00)',NULL,'2026-05-12 05:18:17.243810',1),(115,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-13 07:04:01.809438',1),(116,'RECEIVE PO','Received delivery for PO PO-EE51C0. Inventory stocks and costs updated.',NULL,'2026-05-13 08:35:24.912922',1),(117,'RECEIVE PO','Received delivery for PO PO-88514E. Inventory stocks and costs updated.',NULL,'2026-05-13 08:35:38.191444',1),(118,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-13 08:35:50.757008',1),(119,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-13 08:52:37.824125',1),(120,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-13 10:29:12.999574',1),(121,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-13 10:31:30.362799',1),(122,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-15 03:09:25.631764',1),(123,'POS TRANSACTION','Processed POS transaction TXN-20260515-A28ADE via Cash (Total: ₱3240.00)',NULL,'2026-05-15 03:18:16.307950',1),(124,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-15 03:26:01.449197',1),(125,'SAVE QUOTATION','Saved open transaction as Quotation Ref: TXN-20260515-1A6E79',NULL,'2026-05-15 03:30:17.298391',1),(126,'LOAD QUOTATION','Loaded Quotation Ref: TXN-20260515-1A6E79 into POS cart',NULL,'2026-05-15 03:30:26.167839',1),(127,'POS TRANSACTION','Processed POS transaction TXN-20260515-1A6E79 via Online Bank (Total: ₱500.00)',NULL,'2026-05-15 03:30:37.658415',1),(128,'POS TRANSACTION','Processed POS transaction TXN-20260515-19189A via Trade Credit (Total: ₱125.00)',NULL,'2026-05-15 03:32:37.624985',1),(129,'PAYMENT RECEIVED','Received payment of ₱125.00 for Invoice INV-202605-09FB7 via Cash',NULL,'2026-05-15 03:32:56.105084',1),(130,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-15 08:40:53.957600',1),(131,'RECEIVE PO','Received delivery for PO PO-09D5DE. Inventory stocks and costs updated.',NULL,'2026-05-15 08:45:16.777587',1),(132,'RECEIVE PO','Received delivery for PO PO-CCD6F2. Inventory stocks and costs updated.',NULL,'2026-05-15 08:45:19.890503',1),(133,'POS TRANSACTION','Processed POS transaction TXN-20260515-29FEA9 via Cash (Total: ₱14400.00)',NULL,'2026-05-15 08:46:31.729881',1),(134,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-15 09:24:59.902536',1),(135,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-15 09:25:18.887248',1),(136,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-15 09:25:26.918215',1),(137,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-15 10:15:13.996848',1),(138,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-15 10:15:44.483924',1),(139,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-15 10:15:49.449360',1),(140,'PASSWORD_RESET_REQUEST','User \'JBSON\' requested a password reset.','127.0.0.1','2026-05-15 10:16:00.804988',1),(141,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'JBSON\'.','127.0.0.1','2026-05-15 10:16:16.478021',1),(142,'LOGIN','User \'test\' logged in successfully.','127.0.0.1','2026-05-15 10:17:42.864502',NULL),(143,'PASSWORD_RESET_REQUEST','User \'test4\' requested a password reset.','127.0.0.1','2026-05-15 10:19:43.856045',10),(144,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'test4\'.','127.0.0.1','2026-05-15 10:19:54.955858',1),(145,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-15 10:40:44.405120',1),(146,'PASSWORD_RESET_REQUEST','User \'test4\' requested a password reset.','127.0.0.1','2026-05-15 10:45:30.117732',10),(147,'POS TRANSACTION','Processed POS transaction TXN-20260515-B6DFA8 via Cash (Total: ₱4425.00)',NULL,'2026-05-15 10:47:15.808546',1),(148,'POS TRANSACTION','Processed POS transaction TXN-20260515-EEF89A via Cash (Total: ₱720.00)',NULL,'2026-05-15 10:48:02.306251',1),(149,'POS TRANSACTION','Processed POS transaction TXN-20260515-1D65F5 via Cash (Total: ₱1620.00)',NULL,'2026-05-15 10:48:31.865861',1),(150,'USER_MODIFIED','Admin \'JBSON\' approved password reset for \'test4\'.','127.0.0.1','2026-05-15 10:49:00.688175',1),(151,'RECEIVE PO','Received delivery for PO PO-DA3534. Inventory stocks and costs updated.',NULL,'2026-05-15 10:50:31.990268',1),(152,'RECEIVE PO','Received delivery for PO PO-E22C42. Inventory stocks and costs updated.',NULL,'2026-05-15 10:50:36.080603',1),(153,'ABC ANALYSIS','Executed ABC Inventory Classification analysis and updated item priorities.',NULL,'2026-05-15 10:50:41.213300',1),(154,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-15 10:52:57.278749',1),(155,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-15 10:53:22.611825',1),(156,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-15 10:53:43.649395',1),(157,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-15 10:57:03.826610',1),(158,'LOGOUT','User \'JBSON\' logged out.','127.0.0.1','2026-05-15 10:58:26.527281',1),(159,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-15 10:58:38.511677',1),(160,'POS TRANSACTION','Processed POS transaction TXN-20260515-BF305C via Trade Credit (Total: ₱1475.00)',NULL,'2026-05-15 11:01:37.335049',1),(161,'POS TRANSACTION','Processed POS transaction TXN-20260515-5F71C2 via Cash (Total: ₱11375.00)',NULL,'2026-05-15 11:04:45.858587',1),(162,'GENERATE REPORT','Generated Sales Report from 2026-05-15 to 2026-05-15',NULL,'2026-05-15 11:14:01.039544',1),(163,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-21 09:11:38.878298',1),(164,'POS TRANSACTION','Processed POS transaction TXN-20260521-D55DF0 via Trade Credit (Total: ₱200.00)',NULL,'2026-05-21 09:22:10.809563',1),(165,'PAYMENT RECEIVED','Received payment of ₱100 for Invoice INV-202605-89BA2 via Cash',NULL,'2026-05-21 09:23:09.130495',1),(166,'LOGIN','User \'JBSON\' logged in successfully.','127.0.0.1','2026-05-23 13:37:08.500338',1),(167,'RECEIVE PO','Received delivery for PO PO-720273. Inventory stocks and costs updated.',NULL,'2026-05-23 14:55:35.594998',1),(168,'RECEIVE PO','Received delivery for PO PO-BA380B. Inventory stocks and costs updated.',NULL,'2026-05-23 14:55:40.710105',1);
/*!40000 ALTER TABLE `security_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_employee_profile`
--

DROP TABLE IF EXISTS `security_employee_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_employee_profile` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `recovery_key` varchar(19) NOT NULL,
  `reset_requested` tinyint(1) NOT NULL,
  `reset_approved_by_admin` tinyint(1) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `recovery_key` (`recovery_key`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `security_employee_profile_user_id_5ca94474_fk_security_user_id` FOREIGN KEY (`user_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_employee_profile`
--

LOCK TABLES `security_employee_profile` WRITE;
/*!40000 ALTER TABLE `security_employee_profile` DISABLE KEYS */;
INSERT INTO `security_employee_profile` VALUES (1,'102E-5877-DAB7-4934',1,1,1),(2,'3F4B-EE75-7A66-41AB',1,1,10);
/*!40000 ALTER TABLE `security_employee_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_user`
--

DROP TABLE IF EXISTS `security_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `username` varchar(150) NOT NULL,
  `role` varchar(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `date_created` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_user`
--

LOCK TABLES `security_user` WRITE;
/*!40000 ALTER TABLE `security_user` DISABLE KEYS */;
INSERT INTO `security_user` VALUES (1,'bcrypt_sha256$$2b$12$mAB7Irll3cdJlKBPcj3cRe9wxI6b3BGTFRJ9Qd7BfSJGmhSRuFPUW','2026-05-23 13:37:08.472725',1,'','JBSON','admin',1,1,'2026-05-01 16:29:29.943499'),(8,'bcrypt_sha256$$2b$12$RcNYOU68SuYRQtpX5e152uKIvosv8uZq0BQFi4q.6STHHZ.Qu3yz.','2026-05-10 12:15:55.551041',0,'jewelle lucero','jewelle','Employee',1,0,'2026-05-10 12:15:38.609707'),(10,'bcrypt_sha256$$2b$12$LGthwxAkNntDp1aQHW3qlONsAIhQRHTZfz/RonB65CTYAwe.vyaNG',NULL,0,'test4','test4','Employee',1,0,'2026-05-15 10:18:47.820921');
/*!40000 ALTER TABLE `security_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_user_groups`
--

DROP TABLE IF EXISTS `security_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_groups_user_id_group_id_fc7788e8_uniq` (`user_id`,`group_id`),
  KEY `users_groups_group_id_2f3517aa_fk_auth_group_id` (`group_id`),
  CONSTRAINT `users_groups_group_id_2f3517aa_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `users_groups_user_id_f500bee5_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_user_groups`
--

LOCK TABLES `security_user_groups` WRITE;
/*!40000 ALTER TABLE `security_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_user_user_permissions`
--

DROP TABLE IF EXISTS `security_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_permissions_user_id_permission_id_3b86cbdf_uniq` (`user_id`,`permission_id`),
  KEY `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` (`permission_id`),
  CONSTRAINT `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `users_user_permissions_user_id_92473840_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `security_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_user_user_permissions`
--

LOCK TABLES `security_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `security_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `contact_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(254) NOT NULL,
  `address` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `supplier_id` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'ABC','','','','','2026-05-07 13:39:58.329571','SUP-8EKM',1),(2,'Republic Cement','','','','','2026-05-07 13:59:08.111951','SUP-35V1',1),(3,'Makita PH','','','','','2026-05-07 13:59:55.828156','SUP-M90Y',1),(4,'Amon Marketing','','','','','2026-05-07 14:00:44.583725','SUP-82TI',1),(5,'Pacific Paint','','','','','2026-05-07 14:01:26.325290','SUP-JQDE',1),(6,'Stanley Black&Decker','','','','','2026-05-07 14:02:13.654978','SUP-YB04',1),(7,'Steel Asia','','','','','2026-05-07 14:03:03.517306','SUP-DE12',1),(8,'Atlanta Ind.','','','','','2026-05-07 14:03:42.990863','SUP-OBE0',1),(9,'Yatai Int\'l','','','','','2026-05-07 14:04:28.393196','SUP-YFI1',1),(10,'Gardenia Bakeries','','','','','2026-05-08 08:34:55.794444','SUP-PXCF',1),(11,'Pioneer Adhesives Inc.','','','','','2026-05-09 08:01:50.090993','SUP-40XW',1),(12,'Pacific Paint (Boysen) Phils.','','','','','2026-05-09 08:02:11.853719','SUP-D2LN',1),(13,'3M Philippines','','','','','2026-05-09 08:02:59.526237','SUP-KJDQ',0),(14,'Cord Chemicals Inc.','','','','','2026-05-09 08:03:53.954774','SUP-R35I',1),(15,'Bostik Philippines','','','','','2026-05-09 08:04:37.587176','SUP-G92N',1),(16,'QC Industrial Fasteners','','','','','2026-05-09 08:07:12.481596','SUP-267A',1),(17,'jewelle','JEWELLE RUBY LUCERO','','qjrblucero01@tip.edu.ph','Balayan','2026-05-11 07:37:06.951698',NULL,0);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-24 15:53:29
